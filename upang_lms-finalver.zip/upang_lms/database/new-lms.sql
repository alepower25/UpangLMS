/*
SQLyog Community v13.2.0 (64 bit)
MySQL - 10.4.24-MariaDB : Database - lms
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lms` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `lms`;

/*Table structure for table `author_catalogue` */

DROP TABLE IF EXISTS `author_catalogue`;

CREATE TABLE `author_catalogue` (
  `AuthorId` int(11) NOT NULL,
  `CatalogueId` bigint(20) NOT NULL,
  KEY `fk_1` (`AuthorId`),
  KEY `fk_2` (`CatalogueId`),
  CONSTRAINT `fk_1` FOREIGN KEY (`AuthorId`) REFERENCES `authors` (`AuthorId`),
  CONSTRAINT `fk_2` FOREIGN KEY (`CatalogueId`) REFERENCES `catalogue` (`CatalogueId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `author_catalogue` */

insert  into `author_catalogue`(`AuthorId`,`CatalogueId`) values 
(1,9),
(4,9),
(1,11),
(3,11),
(7,16),
(1,10),
(3,10),
(12,17);

/*Table structure for table `authors` */

DROP TABLE IF EXISTS `authors`;

CREATE TABLE `authors` (
  `AuthorId` int(11) NOT NULL AUTO_INCREMENT,
  `AuthorName` varchar(100) NOT NULL,
  PRIMARY KEY (`AuthorId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

/*Data for the table `authors` */

insert  into `authors`(`AuthorId`,`AuthorName`) values 
(1,'Jay Prakash'),
(2,'Davil J.'),
(3,'Aravind Alex'),
(4,'Haldar Sibsankar'),
(5,'Sandhu'),
(6,'Kenneth'),
(7,'Adele'),
(8,'Rihanna'),
(9,'Brandon Boyd'),
(10,'Anthony Kiedis'),
(11,'Dave Grohl'),
(12,'Ronn Birkmann');

/*Table structure for table `catalogue` */

DROP TABLE IF EXISTS `catalogue`;

CREATE TABLE `catalogue` (
  `CatalogueId` bigint(20) NOT NULL AUTO_INCREMENT,
  `Title` varchar(100) NOT NULL,
  `Year` int(5) NOT NULL,
  `PublisherId` int(11) NOT NULL,
  `TypeId` int(11) NOT NULL,
  `Isbn` varchar(20) NOT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`CatalogueId`),
  UNIQUE KEY `unique_isbn` (`Isbn`),
  KEY `fk1_publisher_id` (`PublisherId`),
  KEY `fk2_type_id_types` (`TypeId`),
  CONSTRAINT `fk1_publisher_id` FOREIGN KEY (`PublisherId`) REFERENCES `publishers` (`PublisherId`),
  CONSTRAINT `fk2_type_id_types` FOREIGN KEY (`TypeId`) REFERENCES `catalogue_types` (`TypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;

/*Data for the table `catalogue` */

insert  into `catalogue`(`CatalogueId`,`Title`,`Year`,`PublisherId`,`TypeId`,`Isbn`,`CreatedAt`,`UpdatedAt`) values 
(9,'Discrete Structures',2021,3,1,'ABC12345','2023-03-01 23:55:18',NULL),
(10,'The PlayBook',2002,2,2,'ABC12346','2023-02-21 23:55:33',NULL),
(11,'Nuclear Physics',1992,1,3,'ABC12347','2022-12-13 23:55:38',NULL),
(13,'General Theory of Relativity',2022,5,1,'ABC12348',NULL,NULL),
(14,'Computer System Architecture',2023,6,2,'ABC12349',NULL,NULL),
(15,'Machine Design',2004,4,1,'ABC123410',NULL,NULL),
(16,'Test',1999,6,1,'XBC123410',NULL,NULL),
(17,'The Art and Science of Digital Compositing',1999,7,1,'156148112',NULL,NULL);

/*Table structure for table `catalogue_catalogue_category` */

DROP TABLE IF EXISTS `catalogue_catalogue_category`;

CREATE TABLE `catalogue_catalogue_category` (
  `CatalogueId` bigint(20) NOT NULL,
  `CatalogueCategoryId` int(11) NOT NULL,
  KEY `fk1_ccc` (`CatalogueId`),
  KEY `fk2_ccc` (`CatalogueCategoryId`),
  CONSTRAINT `fk1_ccc` FOREIGN KEY (`CatalogueId`) REFERENCES `catalogue` (`CatalogueId`),
  CONSTRAINT `fk2_ccc` FOREIGN KEY (`CatalogueCategoryId`) REFERENCES `catalogue_categories` (`CatalogueCatId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `catalogue_catalogue_category` */

insert  into `catalogue_catalogue_category`(`CatalogueId`,`CatalogueCategoryId`) values 
(9,2),
(11,1),
(11,4),
(16,3),
(10,1),
(17,3);

/*Table structure for table `catalogue_categories` */

DROP TABLE IF EXISTS `catalogue_categories`;

CREATE TABLE `catalogue_categories` (
  `CatalogueCatId` int(11) NOT NULL AUTO_INCREMENT,
  `Category` varchar(50) NOT NULL,
  PRIMARY KEY (`CatalogueCatId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

/*Data for the table `catalogue_categories` */

insert  into `catalogue_categories`(`CatalogueCatId`,`Category`) values 
(1,'Computer'),
(2,'Literature'),
(3,'Art'),
(4,'History');

/*Table structure for table `catalogue_meta` */

DROP TABLE IF EXISTS `catalogue_meta`;

CREATE TABLE `catalogue_meta` (
  `CatalogueId` bigint(20) NOT NULL,
  `Status` enum('Available','Borrowed','Missing','Damaged') NOT NULL DEFAULT 'Available',
  `Quantity` int(11) NOT NULL DEFAULT 0,
  KEY `fk1_cm` (`CatalogueId`),
  CONSTRAINT `fk1_cm` FOREIGN KEY (`CatalogueId`) REFERENCES `catalogue` (`CatalogueId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `catalogue_meta` */

insert  into `catalogue_meta`(`CatalogueId`,`Status`,`Quantity`) values 
(9,'Available',10),
(10,'Available',1),
(11,'Available',2),
(11,'Borrowed',0),
(11,'Damaged',2),
(11,'Missing',0),
(9,'Missing',0),
(10,'Borrowed',0),
(10,'Damaged',0),
(10,'Missing',0),
(9,'Borrowed',0),
(9,'Damaged',0),
(16,'Available',1),
(16,'Borrowed',0),
(16,'Damaged',0),
(16,'Missing',0),
(17,'Available',2);

/*Table structure for table `catalogue_types` */

DROP TABLE IF EXISTS `catalogue_types`;

CREATE TABLE `catalogue_types` (
  `TypeId` int(11) NOT NULL AUTO_INCREMENT,
  `Type` varchar(100) NOT NULL,
  PRIMARY KEY (`TypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=30594 DEFAULT CHARSET=utf8mb4;

/*Data for the table `catalogue_types` */

insert  into `catalogue_types`(`TypeId`,`Type`) values 
(1,'Book'),
(2,'Journal'),
(3,'Thesis'),
(4,'Magazine'),
(5,'Type 3'),
(30593,'Book');

/*Table structure for table `departments` */

DROP TABLE IF EXISTS `departments`;

CREATE TABLE `departments` (
  `DepartmentId` int(11) NOT NULL AUTO_INCREMENT,
  `Department` varchar(100) NOT NULL,
  `Code` varchar(5) NOT NULL,
  PRIMARY KEY (`DepartmentId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

/*Data for the table `departments` */

insert  into `departments`(`DepartmentId`,`Department`,`Code`) values 
(1,'CAS','CAS'),
(2,'SHS','SHS'),
(3,'CITE','CITE'),
(4,'CMA','CMA'),
(5,'CEA','CEA'),
(6,'CELA','CELA'),
(7,'CCJE','CCJE'),
(8,'CHS','CHS');

/*Table structure for table `logs` */

DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(30) NOT NULL,
  `model` varchar(50) NOT NULL,
  `model_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `logs` */

/*Table structure for table `message` */

DROP TABLE IF EXISTS `message`;

CREATE TABLE `message` (
  `M_Id` int(10) NOT NULL AUTO_INCREMENT,
  `RollNo` varchar(30) NOT NULL,
  `Msg` varchar(255) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Time` time DEFAULT NULL,
  `UserId` bigint(20) NOT NULL,
  PRIMARY KEY (`M_Id`),
  KEY `RollNo` (`RollNo`),
  KEY `fk1_m_user_id` (`UserId`),
  CONSTRAINT `fk1_m_user_id` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

/*Data for the table `message` */

insert  into `message`(`M_Id`,`RollNo`,`Msg`,`Date`,`Time`,`UserId`) values 
(1,'03-1819-00030','Your request for issue of BookId: 11  has been accepted','2023-03-24','01:16:08',14),
(3,'03-1819-00030','Your request for issue of BookId: 9  has been rejected','2023-03-24','01:18:45',14),
(6,'03-1819-00030','This is a test','2023-03-26','21:20:53',14),
(7,'03-1819-00030','Your request for return of BookId: 11  has been accepted and marked as damaged.','2023-03-26','21:50:27',14),
(8,'03-1819-00030','Your request for issue of BookId: 10  has been accepted','2023-03-28','22:28:10',1),
(9,'03-1819-00030','Your request for return of BookId: 10  has been accepted','2023-03-28','22:34:23',14),
(10,'03-1819-00030','Your request for issue of BookId: 10  has been accepted','2023-03-28','22:37:40',1),
(11,'03-1819-00030','Your request for return of BookId: 10  has been accepted','2023-03-28','22:38:50',14),
(12,'03-1819-00030','Your request for issue of BookId: 9  has been accepted','2023-03-29','21:30:11',1);

/*Table structure for table `publishers` */

DROP TABLE IF EXISTS `publishers`;

CREATE TABLE `publishers` (
  `PublisherId` int(11) NOT NULL AUTO_INCREMENT,
  `Publisher` varchar(100) NOT NULL,
  PRIMARY KEY (`PublisherId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

/*Data for the table `publishers` */

insert  into `publishers`(`PublisherId`,`Publisher`) values 
(1,'NITC'),
(2,'Pearson'),
(3,'Prentice Hall'),
(4,'Marigold'),
(5,'New World Order'),
(6,'ABC'),
(7,'Morgan Kaufmann');

/*Table structure for table `recommendations` */

DROP TABLE IF EXISTS `recommendations`;

CREATE TABLE `recommendations` (
  `R_ID` int(10) NOT NULL AUTO_INCREMENT,
  `Book_Name` varchar(50) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `RollNo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`R_ID`),
  KEY `RollNo` (`RollNo`),
  CONSTRAINT `recommendations_ibfk_1` FOREIGN KEY (`RollNo`) REFERENCES `user` (`RollNo`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `recommendations` */

insert  into `recommendations`(`R_ID`,`Book_Name`,`Description`,`RollNo`) values 
(2,'Book1','Descp1','B160158CS'),
(3,'Book2','Descp2','B160158CS'),
(5,'Operating System','An operating system (OS) is system software that manages computer hardware and software resources and provides common services for computer programs.','b160001cs'),
(7,'Networks ','A computer network, or data network, is a digital telecommunications network which allows nodes to share resources. In computer networks, computing devices exchange data with each other using connections (data links) between nodes.','b160999cs'),
(8,'String Theory','In physics, string theory is a theoretical framework in which the point-like particles of particle physics are replaced by one-dimensional objects called strings. It describes how these strings propagate through space and interact with each other.','b160777cs'),
(9,'The Theory of Everything','The Theory of Everything','b160777cs');

/*Table structure for table `records` */

DROP TABLE IF EXISTS `records`;

CREATE TABLE `records` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `CatalogueId` bigint(20) NOT NULL,
  `DateOfIssue` date DEFAULT NULL,
  `DueDate` date DEFAULT NULL,
  `DateOfReturn` date DEFAULT NULL,
  `BorrowDateTime` datetime NOT NULL,
  `RenewalsLeft` tinyint(3) DEFAULT 0,
  `Dues` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk1_r_user_id` (`UserId`),
  KEY `fk2_r_cata_id` (`CatalogueId`),
  CONSTRAINT `fk1_r_user_id` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`),
  CONSTRAINT `fk2_r_cata_id` FOREIGN KEY (`CatalogueId`) REFERENCES `catalogue` (`CatalogueId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

/*Data for the table `records` */

insert  into `records`(`Id`,`UserId`,`CatalogueId`,`DateOfIssue`,`DueDate`,`DateOfReturn`,`BorrowDateTime`,`RenewalsLeft`,`Dues`) values 
(1,14,11,'2023-03-22','2023-03-23','2023-03-26','2023-03-24 00:09:56',1,'345'),
(4,14,10,'2023-03-28','2023-03-29','2023-03-28','2023-03-28 22:37:02',1,'0'),
(5,14,9,'2023-03-29','2023-03-30','2023-03-29','2023-03-29 21:25:16',1,NULL);

/*Table structure for table `renewals` */

DROP TABLE IF EXISTS `renewals`;

CREATE TABLE `renewals` (
  `RecordId` bigint(20) NOT NULL,
  PRIMARY KEY (`RecordId`),
  CONSTRAINT `fk_ren_reco_id` FOREIGN KEY (`RecordId`) REFERENCES `records` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `renewals` */

/*Table structure for table `returns` */

DROP TABLE IF EXISTS `returns`;

CREATE TABLE `returns` (
  `RecordId` bigint(20) NOT NULL,
  PRIMARY KEY (`RecordId`),
  CONSTRAINT `fk_ret_reco_id` FOREIGN KEY (`RecordId`) REFERENCES `records` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `returns` */

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `UserId` bigint(20) NOT NULL AUTO_INCREMENT,
  `RollNo` varchar(30) NOT NULL,
  `Name` varchar(150) NOT NULL,
  `Type` varchar(10) NOT NULL,
  `DepartmentId` int(11) DEFAULT NULL,
  `Email` varchar(150) NOT NULL,
  `MobileNo` varchar(20) DEFAULT NULL,
  `Password` varchar(50) NOT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`UserId`),
  UNIQUE KEY `unique_rollno` (`RollNo`),
  UNIQUE KEY `unique_email` (`Email`),
  KEY `fk1_dept_id` (`DepartmentId`),
  CONSTRAINT `fk1_dept_id` FOREIGN KEY (`DepartmentId`) REFERENCES `departments` (`DepartmentId`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;

/*Data for the table `users` */

insert  into `users`(`UserId`,`RollNo`,`Name`,`Type`,`DepartmentId`,`Email`,`MobileNo`,`Password`,`CreatedAt`,`UpdatedAt`) values 
(1,'admin','Admin','admin',NULL,'admin@admin.com','09123456789','d033e22ae348aeb5660fc2140aec35850c4da997',NULL,'2023-03-29 23:54:38'),
(2,'03-1415-02012','Ale Meneses Espinoza','student',1,'alme.espinioza.up@phinmaed.com',NULL,'5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8',NULL,'2023-03-29 23:54:38'),
(3,'03-1819-00029','Lance Gio M. De Guzman','student',2,'lame.deguzman.up@phinamed.com',NULL,'5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8',NULL,'2023-03-29 23:54:38'),
(14,'03-1819-00030','First Name 1 Last Name 1','student',1,'student1@email.com','123','e57da4f7d426fb8420b29ea554160c7e020144db',NULL,'2023-03-29 23:54:38');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
