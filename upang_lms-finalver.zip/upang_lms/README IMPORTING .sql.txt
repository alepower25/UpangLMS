Import SQL files into a MySQL database
Sign in to phpMyAdmin.
In phpMyAdmin, on the left menu, select the name of the database you want to use. ...
On the top menu, select Import.
Select Choose file.
Find and select the file you want to import and then select Open.
At the bottom of the page, select Go.


DATABASE NAME- lms

in order ito to prevent error adding 
- author
- book
- journal
- message 
- reccomendations
- record 
- renew
- return
- thesis 
- user

update: wala nang journal at thesis page pero import parin ang .sql file baka 
may possibility ng di mag function ( :( )

