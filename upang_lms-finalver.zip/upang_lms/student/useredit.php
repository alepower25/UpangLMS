<?php
require('dbconn.php');

$pageTitle = 'Profile';

include('common/access-check.php');
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <?php include('common/head.php') ?>
</head>

<body>
    <?php include('common/top-navbar.php') ?>
    <div class="wrapper">
        <div class="container">
            <div class="row">
                <?php include('common/sidebar.php') ?>
                <div class="span9">
                    <center>
                        <div class="card" style="width: 50%;">
                            <img class="card-img-top" src="images/user.png" alt="Card image cap">
                            <div class="card-body">

                                <?php
                                $rollno = $_SESSION['RollNo'];
                                $sql = "select users.*, departments.Code from users join departments on departments.DepartmentId = users.DepartmentId where RollNo='$rollno'";
                                $result = $conn->query($sql);
                                $row = $result->fetch_assoc();

                                $name = $row['Name'];
                                $category = $row['Code'];
                                $email = $row['Email'];
                                $mobno = $row['MobileNo'];
                                ?>
                                <i>
                                    <h1 class="card-title">
                                        <center><?php echo $name ?></center>
                                    </h1>
                                    <br>
                                    <p><b>Email ID: </b><?php echo $email ?></p>
                                    <br>
                                    <p><b>Roll No: </B><?php echo $rollno ?></p>
                                    <br>
                                    <p><b>Department: </b><?php echo $category ?></p>
                                    <br>
                                    <p><b>Mobile number: </b><?php echo $mobno ?></p>
                                    </b>
                                </i>

                            </div>
                        </div>
                        <br>
                        <a href="edit_student_details.php" class="btn btn-primary">Edit Details</a>
                    </center>
                </div>

                <!--/.span9-->
            </div>
        </div>
        <!--/.container-->
    </div>
    <?php include('common/footer.php') ?>

</body>

</html>