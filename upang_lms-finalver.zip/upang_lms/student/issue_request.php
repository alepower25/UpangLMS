<?php
require('dbconn.php');

include('common/access-check.php');

if (!isset($_GET['id'])) {
	http_response_code(405);
    exit;
}

$id = $conn->real_escape_string($_GET['id']);

$availabilityResult = $conn->query('SELECT * FROM catalogue_meta WHERE CatalogueId = '. $id .' AND `Status` = "Available" AND Quantity > 0');

if ($availabilityResult->num_rows < 1) {
	http_response_code(422);
	echo "<script type='text/javascript'>alert('Book is not available!')</script>";
    exit;
}

$conn->query('insert into records (UserId,CatalogueId,BorrowDateTime) values ('.$_SESSION['UserId'].', '.$id.', current_timestamp())');
/*$conn->query('update catalogue_meta SET Quantity = Quantity - 1 WHERE CatalogueId = '. $id. ' AND `Status` = "Available"');
$conn->query('update catalogue_meta SET Quantity = Quantity + 1 WHERE CatalogueId = '. $id. ' AND `Status` = "Borrowed"');*/


if($conn->affected_rows > 0)
{
echo "<script type='text/javascript'>alert('Request Sent to Admin.')</script>";
header( "Refresh:0.01; url=book.php", true, 303);
}
else
{
	echo "<script type='text/javascript'>alert('Request Already Sent.')</script>";
    header( "Refresh:0.01; url=book.php", true, 303);

}




?>