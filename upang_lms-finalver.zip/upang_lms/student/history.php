<?php
require('dbconn.php');

$pageTitle = 'History of Transaction';

include('common/access-check.php');
?>


<!DOCTYPE html>
    <html lang="en">

    <head>
        <?php include('common/head.php') ?>
    </head>

    <body>
        <?php include('common/top-navbar.php') ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php') ?>

                    <div class="span9">
                        <?php
                        $sql = "select records.*, catalogue.* from records JOIN catalogue ON catalogue.CatalogueId = records.CatalogueId where records.UserId = ".$_SESSION['UserId']." and DateOfIssue is NOT NULL and DateOfReturn is NOT NULL";

                        $result = $conn->query($sql);


                        ?>
                            <table class="table datatable-2" id="tables">
                                <thead>
                                    <tr>
                                        <th>Book id</th>
                                        <th>Book name</th>
                                        <th>ISBN</th>
                                        <th>Issue Date</th>
                                        <th>Return Date</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php

                                    if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $bookid = $row['CatalogueId'];
                                        $name = $row['Title'];
                                        $issuedate = $row['DateOfIssue'];
                                        $returndate = $row['DateOfReturn'];
                                    ?>

                                        <tr>
                                            <td><?php echo $bookid ?></td>
                                            <td><?php echo $name ?></td>
                                            <td><?php echo $row['Isbn'] ?></td>
                                            <td><?php echo $issuedate ?></td>
                                            <td><?php echo $returndate ?></td>
                                        </tr>
                                <?php }
                                } ?>
                                </tbody>
                            </table>
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php') ?>
         <script type="text/javascript">
            $(document).ready(function() {

                $('.datatable-2').dataTable({
                    lengthMenu: [500, 1000, 5000, 10000],
                    language: {
                        searchPlaceholder: 'Enter Book Name/Book Id/ISBN'
                    }
                });
                $('.dataTables_paginate').addClass('btn-group datatable-pagination');
                $('.dataTables_paginate > a').wrapInner('<span />');
                $('.dataTables_paginate > a:first-child').append('<i class="icon-chevron-left shaded"></i>');
                $('.dataTables_paginate > a:last-child').append('<i class="icon-chevron-right shaded"></i>');
            });
        </script>
    </body>

</html>