﻿<?php
    require('dbconn.php');

    include('common/access-check.php');

    $borrowedBooksResult = $conn->query('SELECT COUNT(Id) AS `total` FROM `records` WHERE UserId = "'.$_SESSION['UserId'].'" AND DateOfReturn IS NULL AND DateOfIssue IS NOT NULL');
    $borrowedBooks = $borrowedBooksResult->fetch_assoc();


    $returnedBooksResult = $conn->query('SELECT COUNT(Id) AS `total` FROM `records` WHERE UserId = "'.$_SESSION['UserId'].'" AND DateOfReturn IS NOT NULL AND DateOfIssue IS NOT NULL');
    $returnedBooks = $returnedBooksResult->fetch_assoc();

    $pageTitle = 'Dashboard';
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <?php include('common/head.php') ?>
</head>

<body>
    <?php include('common/top-navbar.php') ?>
    <div class="wrapper">
        <div class="container">
            <div class="row">
                <?php include('common/sidebar.php') ?>
                <div class="span9">
                    <div class="row-fluid">
                        <div class="box span3">
                            <div class="card-image">
                                    <img src="/admin/images/borrow.png" height="50" width="50" />
                                </div>
                            <div class="card-body">
                                <div class="card-title">Books Borrowed</div>
                                <p><?php echo $borrowedBooks['total']; ?></p>
                            </div>
                        </div>

                        <div class="box span3">
                            <div class="card-image">
                                <img src="/admin/images/return.png" height="50" width="50" />
                            </div>
                            <div class="card-body">
                                <div class="card-title">Returned Books</div>
                                <p><?php echo $returnedBooks['total']; ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!--/.span9-->
            </div>
        </div>
        <!--/.container-->
    </div>
    <?php include('common/footer.php') ?>

</body>

</html>