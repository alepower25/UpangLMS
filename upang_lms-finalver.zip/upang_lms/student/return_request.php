<?php
require('dbconn.php');

include('common/access-check.php');

$id = isset($_GET['id']) ? $conn->real_escape_string($_GET['id']) : null;

if (empty($id)) {
    http_response_code(422);
    exit;
}

$recordResult = $conn->query('SELECT Id,DueDate,BorrowDateTime, CatalogueId FROM records WHERE UserId = '. $_SESSION['UserId'].' AND CatalogueId = '. $id);

if ($recordResult->num_rows == 0) {
	http_response_code(422);
    exit;
}

$recordRow = $recordResult->fetch_assoc();

if (strtotime($recordRow['DueDate'] . date('H:i:s', strtotime($recordRow['BorrowDateTime']))) > time()) {
    $conn->query('UPDATE records SET DateOfReturn = CURDATE() WHERE Id = '.$recordRow['Id']);

    if ($conn->affected_rows > 0) {
        $conn->query('UPDATE catalogue_meta SET Quantity = Quantity + 1 WHERE `Status` = "Available" AND CatalogueId = '. $recordRow['CatalogueId']);

        $conn->query('UPDATE catalogue_meta SET Quantity = Quantity - 1 WHERE `Status` = "Borrowed" AND CatalogueId = '. $recordRow['CatalogueId']);
    }

} else {
    $conn->query("insert into returns (RecordId) values (".$recordRow['Id'].")");
}

if ($conn->affected_rows > 0)
{
	echo "<script type='text/javascript'>alert('Request Sent to Admin.')</script>";
	header( "Refresh:0.01; url=current.php", true, 303);
}
else
{
	echo "<script type='text/javascript'>alert('Request Already Sent.')</script>";
    header( "Refresh:0.01; url=current.php", true, 303);

}

?>