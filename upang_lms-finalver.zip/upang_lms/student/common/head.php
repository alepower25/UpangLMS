<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($pageTitle) ? $pageTitle : 'LMS'; ?></title>
<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
<link type="text/css" href="css/theme.css" rel="stylesheet">
<link type="text/css" href="css/select2.min.css" rel="stylesheet">
<link type="text/css" href="css/select2-bootstrap.min.css" rel="stylesheet">
<link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
<link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>

<style>
    .loader {
        position: absolute;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0, 0.3);
        top: 0;
        color: #fff;
        font-size: 30px;
        text-align: center;
        vertical-align: middle;
    }

    .loader span {
        position: relative;
        top: 50%;
    }

    .select2-selection__choice__remove {
        border: 0 none;
        background: none;
    }

    .select2-search__field {
        box-shadow: unset!important;
    }

    .select2-container--bootstrap .select2-selection--multiple .select2-search--inline .select2-search__field {
        padding-bottom: 6px;
        padding-top: 6px;
    }

    .dataTables_wrapper .select2-container--bootstrap {
        display: inline-block;
    }

    .dataTables_length select {
        width: 100px;
    }
</style>