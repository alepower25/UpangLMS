<div class="span3">
    <div class="sidebar">
        <ul class="widget widget-menu unstyled">
            <li <?php if (is_nav_active('index.php')) { ?>class="active"<?php } ?>><a href="index.php"><i class="menu-icon icon-home"></i>Dashboard
                </a></li>
            </li>
            <li <?php if (is_nav_active('book.php')) { ?>class="active"<?php } ?>><a href="book.php"><i class="menu-icon icon-book"></i>Transaction </a></li>
            <li <?php if (is_nav_active('history.php')) { ?>class="active"<?php } ?>><a href="history.php"><i class="menu-icon icon-tasks"></i>History of Transaction </a></li>
            <li <?php if (is_nav_active('current.php')) { ?>class="active"<?php } ?>><a href="current.php"><i class="menu-icon icon-list"></i>Currently Issued Books </a></li>
        </ul>
        <ul class="widget widget-menu unstyled">
            <li><a href="logout.php"><i class="menu-icon icon-signout"></i>Logout </a></li>
        </ul>
    </div>
    <!--/.sidebar-->
</div>
<!--/.span3-->