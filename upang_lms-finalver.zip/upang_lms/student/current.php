<?php
require('dbconn.php');

$pageTitle = 'Currently Issued Books';

include('common/access-check.php');
?>

<!DOCTYPE html>
    <html lang="en">

    <head>
        <?php include('common/head.php') ?>
    </head>

    <body>
        <?php include('common/top-navbar.php') ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php') ?>
                    <div class="span9">

                        <?php

                            $sql = "select * from records JOIN catalogue ON catalogue.CatalogueId = records.CatalogueId left join returns on records.Id = returns.RecordId where records.UserId = ".$_SESSION['UserId']." and DateOfIssue is NOT NULL and DateOfReturn is NULL";

                        $result = $conn->query($sql);
                        ?>
                            <table class="table datatable-2" id="tables">
                                <thead>
                                    <tr>
                                        <th>Book id</th>
                                        <th>Book name</th>
                                        <th>ISBN</th>
                                        <th>Issue Date</th>
                                        <th>Due date</th>
                                        <th>Penalty per Day</th>
                                        <th>Due</th>
                                        <th><div class="text-center">Actions</div></th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php
                                    if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $bookid = $row['CatalogueId'];
                                        $name = $row['Title'];
                                        $issuedate = $row['DateOfIssue'];
                                        $duedate = $row['DueDate'];
                                        $renewals = $row['RenewalsLeft'];
                                        $dues = compute_penalty($duedate);

                                    ?>

                                        <tr>
                                            <td><?php echo $bookid ?></td>
                                            <td><?php echo $name ?></td>
                                            <td><?php echo $row['Isbn'] ?></td>
                                            <td><?php echo $issuedate ?></td>
                                            <td><?php echo $duedate ?></td>
                                            <td>120 per day (fixed value)</td>
                                            <td><?php if ($dues > 0)
                                                    echo "<font color='red'>" . number_format($dues, 2) . "</font>";
                                                else
                                                    echo "<font color='green'>0</font>";
                                                ?></td>
                                            <td>
                                                <center>
                                                    <?php if (!empty($row['RecordId'])) { ?>
                                                    <em>Pending Return</em>
                                                    <?php } else {
                                                    if ($renewals)
                                                        echo "<a href=\"renew_request.php?id=" . $bookid . "\" class=\"btn btn-success\">Renew</a>";
                                                    ?>
                                                    <a href="return_request.php?id=<?php echo $bookid; ?>" class="btn btn-primary">Return</a>
                                                <?php } ?>
                                                </center>
                                            </td>
                                        </tr>
                                <?php }
                                } ?>
                                </tbody>
                            </table>
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php') ?>
        <script type="text/javascript">
            $(document).ready(function() {

                $('.datatable-2').dataTable({
                    lengthMenu: [500, 1000, 5000, 10000],
                    language: {
                        searchPlaceholder: 'Enter Book Name/Book Id/ISBN'
                    }
                });
                $('.dataTables_paginate').addClass('btn-group datatable-pagination');
                $('.dataTables_paginate > a').wrapInner('<span />');
                $('.dataTables_paginate > a:first-child').append('<i class="icon-chevron-left shaded"></i>');
                $('.dataTables_paginate > a:last-child').append('<i class="icon-chevron-right shaded"></i>');
            });
        </script>
    </body>

    </html>