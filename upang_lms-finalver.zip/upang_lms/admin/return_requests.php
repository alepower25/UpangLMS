<?php
require('dbconn.php');

include('common/access-check.php');

$pageTitle = "Return Request";
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <?php include('common/head.php'); ?>
        <style type="text/css">
            #tables_filter input {
                width: 300px;
            }
        </style>
    </head>

    <body>
       <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                     <?php include('common/sidebar.php'); ?>
                    <div class="span9">

                        <h1><i>Return Requests</i></h1>
                        <table class="table datatable-2" id="tables">
                            <thead>
                                <tr>
                                    <th>Student Number</th>
                                    <th>Book Id</th>
                                    <th>Book Name</th>
                                    <th>ISBN</th>
                                    <th>Issue Date</th>
                                    <th>Due date</th>
                                    <th>Penalty per Day</th>
                                    <th>Due (₱)</th>
                                     <th><div class="text-center">Actions</div></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = 'SELECT * FROM records JOIN returns ON returns.RecordId = records.Id JOIN users on users.UserId = records.UserId JOIN catalogue ON catalogue.CatalogueId = records.CatalogueId';
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $recordId = $row['Id'];
                                    $bookid = $row['CatalogueId'];
                                    $rollno = $row['RollNo'];
                                    $userid = $row['UserId'];
                                    $name = $row['Title'];
                                    $dues = compute_penalty($row['DueDate']);

                                ?>
                                    <tr>
                                        <td><?php echo strtoupper($rollno) ?></td>
                                        <td><?php echo $bookid ?></td>
                                        <td><b><?php echo $name ?></b></td>
                                        <td><?php echo $row['Isbn'] ?></td>
                                        <td><?php echo $row['DateOfIssue'] ?></td>
                                        <td><?php echo $row['DueDate'] ?></td>
                                        <td>120 per day (fixed value)</td>
                                        <td><?php
                                            if ($dues > 0)
                                                echo number_format($dues, 2);
                                            else
                                                echo 0; ?></td>
                                        <td>
                                            <center>

                                                <a href="acceptreturn.php?id=<?php echo $recordId; ?>" class="btn btn-success">Accept</a>
                                                <a href="markdamaged.php?id=<?php echo $recordId; ?>" class="btn btn-warning">Damaged</a>

                                                <!--a href="rejectreturn.php?id1=<?php echo $bookid; ?>&id2=<?php echo $rollno; ?>" class="btn btn-danger">Reject</a-->
                                            </center>
                                        </td>
                                    </tr>
                                 <?php }  }  ?>
                            </tbody>
                        </table>
                    </div>
                    <!--/.span3-->
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php'); ?>
         <script type="text/javascript">
            $(document).ready(function() {

                $('.datatable-2').dataTable({
                    lengthMenu: [500, 1000, 5000, 10000],
                    language: {
                        searchPlaceholder: 'Enter Student Number/Book Name/Book Id/ISBN'
                    }
                });
                $('.dataTables_paginate').addClass('btn-group datatable-pagination');
                $('.dataTables_paginate > a').wrapInner('<span />');
                $('.dataTables_paginate > a:first-child').append('<i class="icon-chevron-left shaded"></i>');
                $('.dataTables_paginate > a:last-child').append('<i class="icon-chevron-right shaded"></i>');
            });
        </script>
    </body>

    </html>