<?php
require('dbconn.php');

include('common/access-check.php');

$bookid=isset($_GET['id1']) ? $conn->real_escape_string($_GET['id1']) : null;
$rollno=isset($_GET['id2']) ? $conn->real_escape_string($_GET['id2']) : null;

if (empty($bookid) || empty($rollno)) {
    http_response_code(422);
    exit;
}

$bookResult = $conn->query('select CatalogueId from catalogue where catalogueId = '. $bookid.' LIMIT 1');
$userResult = $conn->query('select * from users JOIN departments ON departments.DepartmentId = users.DepartmentId where UserId = '. $rollno.' LIMIT 1');

if ($bookResult->num_rows == 0 || $userResult->num_rows == 0) {
    http_response_code(422);
    exit;
}

$row = $userResult->fetch_assoc();

$conn->query("delete from records where UserId='$rollno' and CatalogueId='$bookid'");

if($conn->affected_rows > 0)
    {
	$sql1="insert into message (RollNo,Msg,Date,Time,UserId) values ('".$row['RollNo']."','Your request for issue of BookId: $bookid  has been rejected',curdate(),curtime(), ".$_SESSION['UserId'].")";
 $result=$conn->query($sql1);
echo "<script type='text/javascript'>alert('Success')</script>";
header( "Refresh:0.01; url=issue_requests.php", true, 303);
}
else
{
	echo "<script type='text/javascript'>alert('Error')</script>";
    header( "Refresh:0.01; url=issue_requests.php", true, 303);

}




?>