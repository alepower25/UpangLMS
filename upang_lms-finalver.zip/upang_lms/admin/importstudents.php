<?php

require('dbconn.php');

include('common/header-json.php');
include('common/access-check.php');


if (!isset($_FILES['file'])) {
    http_response_code(405);
    exit;
}

$allowedFileTypes = ['csv' => 'text/csv'];
$actualfile = $_FILES['file']['tmp_name'];
$filename = $_FILES['file']['name'];
$filetype = $_FILES['file']['type'];
$filesize = $_FILES['file']['size'];

$extension = pathinfo($filename, PATHINFO_EXTENSION);

if (!array_key_exists($extension, $allowedFileTypes)) {
    http_response_code(422);
    echo json_encode(['message' => 'Please correct the errors found.', 'errors' => [['key' => 'file', 'val' => 'Invalid file format. Only CSV file is allowed.']]]);
    exit;
}

if ($filesize > 52428800) {
    http_response_code(422);
    echo json_encode(['message' => 'Please correct the errors found.', 'errors' => [['key' => 'file', 'val' => 'Exceeded 50MB file size limit.']]]);
    exit;
}

$success = [];
$failure = [];

$file = fopen($actualfile, 'r');
$index = 0;
fgetcsv($file);
while (($data = fgetcsv($file, 10000, ',')) !== FALSE) {

    list($studentNumber, $firstName, $lastName, $department, $email, $mobileNumber) = $data;

    if ((empty($studentNumber) || empty($firstName) || empty($lastName) || empty($department) || empty($email)) && $index === 0) {
        break;
    }

    $studentNumberResult = $conn->query('SELECT UserId FROM users WHERE RollNo = "'. $conn->real_escape_string($studentNumber).'" LIMIT 1');

    if ($studentNumberResult->num_rows > 0) {
        $failure[] = $index;
        $index++;
        continue;
    }

    $emailResult = $conn->query('SELECT UserId FROM users WHERE LOWER(Email) = "'. strtolower($conn->real_escape_string($email)).'" LIMIT 1');

    if ($emailResult->num_rows > 0) {
        $failure[] = $index;
        $index++;
        continue;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $failure[] = $index;
        $index++;
        continue;
    }

    if (!empty($mobileNumber) && !is_numeric($mobileNumber)) {
        $failure[] = $index;
        $index++;
        continue;
    }

    $departmentResult = $conn->query('SELECT DepartmentId FROM departments WHERE LOWER(Code) = "'.$conn->real_escape_string(strtolower($department)).'" LIMIT 1;');

    if ($departmentResult->num_rows < 1) {
        $failure[] = $index;
        $index++;
        continue;
    } else {
        $departmentRow = $departmentResult->fetch_assoc();
        $departmentId = $departmentRow['DepartmentId'];
    }

    $name = $firstName . " ". $lastName;
    $conn->query('INSERT INTO users (RollNo, Name, Type, DepartmentId, Email, MobileNo, Password) VALUES ("'.$conn->real_escape_string($studentNumber).'", "'.$conn->real_escape_string($name).'", "student", '.$departmentId.',"'.$conn->real_escape_string($email).'","'.$conn->real_escape_string($mobileNumber).'","'.$conn->real_escape_string(sha1(strtoupper($lastName))) .'")');

    $success[] = $index;
    $index++;
}

fclose($file);

echo json_encode(['message' => 'There were '.count($failure).' failed imports and '.count($success).' successful imports.']);