<?php
require('dbconn.php');

include('common/header-json.php');
include('common/access-check.php');
include('common/check-error-422.php');

$category = isset($_POST['category']) ? $_POST['category'] : null;

if (empty($category)) {
    http_response_code(422);
    echo json_encode(['errors' => [['key' => 'category', 'val' => 'Category field is required.']], 'message' => 'Please correct the errors found.']);
    exit;
}

$conn->query('INSERT INTO catalogue_categories (Category) VALUES ("' . $conn->real_escape_string($category) . '")');

if ($conn->affected_rows < 1) {
    http_response_code(422);
    echo json_encode(['message' => 'Unable to insert data into the database.']);
    exit;
}

echo json_encode(['message' => 'Category has been successfully added!', 'data' => ['id' => $conn->insert_id, 'value' => $category]]);