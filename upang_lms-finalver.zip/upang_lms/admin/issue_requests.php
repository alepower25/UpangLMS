<?php
require('dbconn.php');

include('common/access-check.php');

$pageTitle = "Issue Request";
?>
<!DOCTYPE html>
    <html lang="en">

    <head>
        <?php include('common/head.php'); ?>
        <style type="text/css">
            #tables_filter input {
                width: 300px;
            }
        </style>
    </head>

    <body>
        <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                     <?php include('common/sidebar.php'); ?>
                    <div class="span9">
                        <h1><i>Issue Requests</i></h1>
                        <table class="table datatable-2" id="tables">
                            <thead>
                                <tr>
                                    <th>Student Number</th>
                                    <th>Book Id</th>
                                    <th width="25%">Book Name</th>
                                    <th width="10%">ISBN</th>
                                    <th width="25%">Availabilty</th>
                                    <th><div class="text-center">Actions</div></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "select * from records JOIN catalogue on catalogue.CatalogueId = records.CatalogueId JOIN users on users.UserId = records.UserId JOIN catalogue_meta on catalogue.CatalogueId = catalogue_meta.CatalogueId and `Status` = 'Available' where DateOfIssue is NULL order by BorrowDateTime ASC";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $bookid = $row['CatalogueId'];
                                    $rollno = $row['UserId'];
                                    $name = $row['Title'];
                                    $avail = $row['Quantity'];


                                ?>
                                    <tr>
                                        <td><?php echo strtoupper($rollno) ?></td>
                                        <td><?php echo $bookid ?></td>
                                        <td><b><?php echo $name ?></b></td>
                                        <td><?php echo $row['Isbn'] ?></td>
                                        <td><?php echo $avail ?></td>
                                        <td>
                                            <center>
                                                <?php
                                                if ($avail > 0) {
                                                    echo "<a href=\"accept.php?id1=" . $bookid . "&id2=" . $rollno . "\" class=\"btn btn-success\">Approve</a>";
                                                }
                                                ?>
                                                <a href="reject.php?id1=<?php echo $bookid ?>&id2=<?php echo $rollno ?>" class="btn btn-danger">Reject</a>
                                            </center>
                                        </td>
                                    </tr>
                                <?php } }  ?>
                            </tbody>
                        </table>
                    </div>
                    <!--/.span3-->
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php'); ?>
        <script type="text/javascript">
            $(document).ready(function() {

                $('.datatable-2').dataTable({
                    lengthMenu: [500, 1000, 5000, 10000],
                    language: {
                        searchPlaceholder: 'Enter Student Number/Book Name/Book Id/ISBN'
                    }
                });
                $('.dataTables_paginate').addClass('btn-group datatable-pagination');
                $('.dataTables_paginate > a').wrapInner('<span />');
                $('.dataTables_paginate > a:first-child').append('<i class="icon-chevron-left shaded"></i>');
                $('.dataTables_paginate > a:last-child').append('<i class="icon-chevron-right shaded"></i>');
            });
        </script>
    </body>

</html>
