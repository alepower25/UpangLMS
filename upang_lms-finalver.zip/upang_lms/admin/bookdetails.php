<?php
require('dbconn.php');

include('common/access-check.php');

$pageTitle = "Catalogue Details";
?>

<!DOCTYPE html>
    <html lang="en">

    <head>
        <?php include('common/head.php'); ?>
    </head>

    <body>
        <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php'); ?>

                    <div class="span9">
                        <div class="content">

                            <div class="module">
                                <div class="module-head">
                                    <h3>Book Details</h3>
                                </div>
                                <div class="module-body">
                                    <?php
                                    $x = $conn->real_escape_string($_GET['id']);
                                    $sql = "select catalogue.*, publishers.Publisher, catalogue_types.Type from catalogue JOIN publishers ON publishers.PublisherId = catalogue.PublisherId JOIN catalogue_types ON catalogue_types.TypeId = catalogue.TypeId where CatalogueId='$x'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();

                                    $bookid = $row['CatalogueId'];
                                    $name = $row['Title'];
                                    $publisher = $row['Publisher'];
                                    $year = $row['Year'];

                                    echo "<b>Book ID:</b> " . $bookid . "<br><br>";
                                    echo "<b>Title:</b> " . $name . "<br><br>";
                                    $sql1 = "select authors.AuthorName from authors JOIN author_catalogue ON author_catalogue.AuthorId = authors.AuthorId where CatalogueId='$bookid'";
                                    $result = $conn->query($sql1);

                                    echo "<b>Author(s):</b> ";
                                    $authorNames = '';
                                    while ($row1 = $result->fetch_assoc()) {
                                       $authorNames .= $row1['AuthorName'] . ", ";
                                    }
                                    echo rtrim($authorNames, ', ');
                                    echo "<br><br>";
                                    echo "<b>Publisher:</b> " . $publisher . "<br><br>";

                                    $sql1 = "select catalogue_categories.Category from catalogue_categories JOIN catalogue_catalogue_category ON catalogue_catalogue_category.CatalogueCategoryId = catalogue_categories.CatalogueCatId where CatalogueId='$bookid'";
                                    $result = $conn->query($sql1);
                                    echo "<b>Categories:</b> ";
                                    $categoryNames = '';
                                    while ($row1 = $result->fetch_assoc()) {
                                       $categoryNames .= $row1['Category'] . ", ";
                                    }
                                    echo rtrim($categoryNames, ', ');
                                    echo "<br><br>";
                                    echo "<b>Year:</b> " . $year . "<br><br>";

                                    $sql1 = "select * from catalogue_meta where CatalogueId='$bookid'";
                                    $result = $conn->query($sql1);
                                    echo "<b>Availability:</b> <br>";
                                    $availability = '';
                                    while ($row1 = $result->fetch_assoc()) {
                                       $availability .= $row1['Status'].' - '.$row1['Quantity'].', ';
                                    }
                                    echo rtrim($availability, ', ');
                                    echo "<br><br>";
                                    ?>

                                    <a href="book.php" class="btn btn-primary">Go Back</a>
                                </div>
                            </div>
                        </div>
                        <!--/.span3-->
                        <!--/.span9-->

                        <!--/.span3-->
                        <!--/.span9-->
                    </div>
                </div>
                <!--/.container-->
            </div>
            <?php include('common/footer.php'); ?>
    </body>
</html>
