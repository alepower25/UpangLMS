<?php
require('dbconn.php');

include('common/access-check.php');

$pageTitle = "Catalogue";


$catalogueResults = $conn->query('SELECT catalogue.CatalogueId, catalogue.Title, catalogue.Year, publishers.Publisher, GROUP_CONCAT(catalogue_categories.Category) as `categories`, GROUP_CONCAT(catalogue_meta.Status) as `statuses`, GROUP_CONCAT(catalogue_meta.Quantity) as quantities, catalogue_types.Type FROM catalogue JOIN catalogue_types ON catalogue_types.TypeId = catalogue.TypeId JOIN catalogue_catalogue_category ON catalogue.CatalogueId = catalogue_catalogue_category.CatalogueId JOIN catalogue_categories ON catalogue_categories.CatalogueCatId = catalogue_catalogue_category.CatalogueCategoryId LEFT JOIN catalogue_meta ON catalogue_meta.CatalogueId = catalogue.CatalogueId JOIN publishers on publishers.PublisherId = catalogue.PublisherId GROUP BY catalogue.CatalogueId ORDER BY Title ASC');

?>
<!DOCTYPE html>
    <html lang="en">

    <head>
         <?php include('common/head.php'); ?>
    </head>

    <body>
        <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php'); ?>

                    <div class="span9">
                        <!-- <form class="form-horizontal row-fluid" action="book.php" method="post">
                            <div class="control-group">
                                <label class="control-label" for="Search"><b>Search:</b></label>
                                <div class="controls">
                                    <input type="text" id="title" name="title" placeholder="Enter Name/ID of Book" class="span8" required>
                                    <button type="submit" name="submit" class="btn">Search</button>
                                </div>
                            </div>
                        </form>
                        <br> -->
                        <?php
                        /*if (isset($_POST['submit'])) {
                            $s = $_POST['title'];
                            $sql = "select * from LMS.book where BookId='$s' or Title like '%$s%'";
                        } else
                            $sql = "select * from LMS.book";

                        $result = $conn->query($sql);*/


                        ?>
                            <table class="table table-catalogue" id="tables">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th width="30%">Title</th>
                                        <!-- <th width="15%">Categories</th> -->
                                        <th width="15%">Type</th>
                                        <th width="30%">Availability</th>
                                        <th><div class="text-center">Actions</div></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($catalogueResults->num_rows > 0) {
                                        while ($row = $catalogueResults->fetch_assoc()) {
                                    ?>
                                        <tr>
                                            <td><?php echo $row['CatalogueId']; ?></td>
                                            <td><?php echo $row['Title']; ?></td>
                                            <!-- <td>
                                            <?php
                                                $categories = array_unique(explode(',', $row['categories']));

                                                foreach($categories as $category) {
                                            ?>
                                            <span class="label"><?php echo $category; ?></span>
                                                <?php } ?>
                                            </td> -->
                                            <td><?php echo $row['Type']; ?></td>
                                            <td>
                                                <?php
                                                    $statuses = explode(',', $row['statuses']);
                                                    //$quantities = explode(',', $row['quantities']);

                                                    foreach($statuses as $index => $status) {


                                                        switch($status) {
                                                            case 'Available':
                                                                $statusClass = 'label-success';
                                                                break;
                                                            case 'Borrowed':
                                                                $statusClass = 'label-info';
                                                                break;
                                                            case 'Missing':
                                                                $statusClass = 'label-warning';
                                                                break;
                                                            case 'Damaged':
                                                                $statusClass = 'label-important';
                                                                break;
                                                            default:
                                                                $statusClass = '';
                                                                break;
                                                        }

                                                ?>
                                                    <span class="label <?php echo $statusClass; ?>"><?php echo $status; ?></span>
                                                <?php } ?>
                                            </td>
                                            <td>
                                                <div class="text-center">
                                                    <a href="cataloguedetails.php?id=<?php echo $row['CatalogueId']; ?>" class="btn btn-primary">Details</a>
                                                    <a href="edit_cataloguedetails.php?id=<?php echo $row['CatalogueId']; ?>" class="btn btn-success">Edit</a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php'); ?>
        <script type="text/javascript">
            $(document).ready(function () {
                $('.table-catalogue').dataTable({
                    'lengthMenu': [500, 1000, 5000, 10000]
                });

                $('.dataTables_paginate').addClass('btn-group datatable-pagination');
                $('.dataTables_paginate > a').wrapInner('<span />');
                $('.dataTables_paginate > a:first-child').append('<i class="icon-chevron-left shaded"></i>');
                $('.dataTables_paginate > a:last-child').append('<i class="icon-chevron-right shaded"></i>');
            });
        </script>
    </body>

</html>
