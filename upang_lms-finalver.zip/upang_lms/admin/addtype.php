<?php
require('dbconn.php');

include('common/header-json.php');
include('common/access-check.php');
include('common/check-error-422.php');

$type = isset($_POST['type']) ? $_POST['type'] : null;

if (empty($type)) {
    http_response_code(422);
    echo json_encode(['errors' => [['key' => 'type', 'val' => 'Type field is required.']], 'message' => 'Please correct the errors found.']);
    exit;
}

$conn->query('INSERT INTO catalogue_types (Type) VALUES ("' . $conn->real_escape_string($type) . '")');

if ($conn->affected_rows < 1) {
    http_response_code(422);
    echo json_encode(['message' => 'Unable to insert data into the database.']);
    exit;
}

echo json_encode(['message' => 'Type has been successfully added!', 'data' => ['id' => $conn->insert_id, 'value' => $type]]);