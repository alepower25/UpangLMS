<?php
require('dbconn.php');

include('common/access-check.php');

$pageTitle = "All Books";


$catalogueResults = $conn->query('SELECT catalogue.CatalogueId, catalogue.Isbn, catalogue.Title, catalogue.Year, publishers.Publisher, GROUP_CONCAT(catalogue_categories.Category) as `categories`, GROUP_CONCAT(catalogue_meta.Status) as `statuses`, GROUP_CONCAT(catalogue_meta.Quantity) as quantities, catalogue_types.Type FROM catalogue JOIN catalogue_types ON catalogue_types.TypeId = catalogue.TypeId JOIN catalogue_catalogue_category ON catalogue.CatalogueId = catalogue_catalogue_category.CatalogueId JOIN catalogue_categories ON catalogue_categories.CatalogueCatId = catalogue_catalogue_category.CatalogueCategoryId LEFT JOIN catalogue_meta ON catalogue_meta.CatalogueId = catalogue.CatalogueId JOIN publishers on publishers.PublisherId = catalogue.PublisherId GROUP BY catalogue.CatalogueId ORDER BY Title ASC');

$typeResults = $conn->query('SELECT * FROM catalogue_types ORDER BY Type ASC');

$categoryResults = $conn->query('SELECT * FROM catalogue_categories ORDER BY Category ASC');

?>
<!DOCTYPE html>
    <html lang="en">

    <head>
         <?php include('common/head.php'); ?>
         <style type="text/css">
             #tables_filter {
                display: none;
             }

             .select2-container--bootstrap .select2-selection,
             .typeahead {
                text-align: left;
             }
         </style>
    </head>

    <body>
        <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php'); ?>

                    <div class="span9">
                        <div class="form-inline text-center" method="get">
                            <div class="control-group">
                                <label class="control-label" for="s"><b>Search:</b></label>
                                <input type="text" id="s" name="s" placeholder="Enter Name/ID of Book/ISBN" style="width: 250px">
                                <select name="category" multiple data-placeholder="Select a category">
                                    <?php
                                        if ($categoryResults->num_rows > 0) {
                                            while($categoryRow = $categoryResults->fetch_assoc()) {
                                    ?>
                                    <option value="<?php echo $categoryRow['Category']; ?>"><?php echo $categoryRow['Category']; ?></option>
                                    <?php
                                            }
                                        }
                                    ?>
                                </select>
                                <select name="type" multiple data-placeholder="Select a type">
                                    <?php
                                        if ($typeResults->num_rows > 0) {
                                            while($typeRow = $typeResults->fetch_assoc()) {
                                    ?>
                                    <option value="<?php echo $typeRow['Type']; ?>"><?php echo $typeRow['Type']; ?></option>
                                    <?php
                                            }
                                        }
                                    ?>
                                </select>
                                <button type="button" name="btn-search" class="btn">Search</button>
                            </div>
                        </div>
                        <br>

                            <table class="table table-catalogue" id="tables" style="width: 100%!important">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th width="25%">Title</th>
                                        <th width="10%">ISBN</th>
                                        <th>Categories</th>
                                        <th width="10%">Type</th>
                                        <th width="30%">Availability</th>
                                        <th><div class="text-center">Actions</div></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($catalogueResults->num_rows > 0) {
                                        while ($row = $catalogueResults->fetch_assoc()) {
                                    ?>
                                        <tr>
                                            <td><?php echo $row['CatalogueId']; ?></td>
                                            <td><?php echo $row['Title']; ?></td>
                                            <td><?php echo $row['Isbn']; ?></td>
                                            <td>
                                            <?php
                                                $categories = array_unique(explode(',', $row['categories']));

                                                foreach($categories as $category) {
                                            ?>
                                            <span class="label"><?php echo $category; ?></span>
                                                <?php } ?>
                                            </td>
                                            <td><?php echo $row['Type']; ?></td>
                                            <td data>
                                                <?php
                                                    $statuses = array_unique(explode(',', $row['statuses']));
                                                    $quantities = explode(',', $row['quantities']);

                                                    foreach($statuses as $index => $status) {
                                                        if ($status === 'Available' && $quantities[$index] == 0) {
                                                            $status = 'Unavailable';
                                                            $statusClass = '';
                                                        } else {
                                                            if ($quantities[$index] == 0)  {
                                                                continue;
                                                            }

                                                            switch($status) {
                                                                case 'Available':
                                                                    $statusClass = 'label-warning';
                                                                    break;
                                                                case 'Borrowed':
                                                                    $statusClass = 'label-info';
                                                                    break;
                                                                case 'Damaged':
                                                                    $statusClass = 'label-important';
                                                                    break;
                                                                case 'Missing':
                                                                default:
                                                                    $statusClass = '';
                                                                    break;
                                                            }
                                                        }

                                                ?>
                                                    <span class="label <?php echo $statusClass; ?>"><?php echo $status; ?></span>
                                                <?php } ?>
                                            </td>
                                            <td>
                                                <div class="text-center">
                                                    <a href="bookdetails.php?id=<?php echo $row['CatalogueId']; ?>" class="btn btn-primary">Details</a>
                                                    <a href="edit_bookdetails.php?id=<?php echo $row['CatalogueId']; ?>" class="btn btn-success">Edit</a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php'); ?>
        <script type="text/javascript">
            $(document).ready(function () {
                var dt = $('.table-catalogue').DataTable({
                    lengthMenu: [500, 1000, 5000, 10000],
                    columnDefs: [
                        {
                            targets: [3],
                            visible: false
                        }
                    ]
                });

                $('[name="btn-search"]').on('click', function () {
                    var typeValue = $('[name="type"]').val();
                    var catValue = $('[name="category"]').val();
                    var sValue = $('#s').val();

                    if (typeValue !== null) {
                        dt.column(4).search($.fn.dataTable.util.escapeRegex(typeValue.join('|')), true, false).draw();
                    }

                    if (catValue !== null) {
                        dt.column(3).search($.fn.dataTable.util.escapeRegex(catValue.join('|')), true, false).draw();
                    }

                    if (sValue !== '') {
                        dt.search(sValue, true, false).draw();
                    }

                    if (typeValue == null && sValue == '' && catValue == null) {
                        dt.search('').columns().search('').draw();
                    }
                });

                $('.dataTables_paginate').addClass('btn-group datatable-pagination');
                $('.dataTables_paginate > a').wrapInner('<span />');
                $('.dataTables_paginate > a:first-child').append('<i class="icon-chevron-left shaded"></i>');
                $('.dataTables_paginate > a:last-child').append('<i class="icon-chevron-right shaded"></i>');
            });
        </script>
    </body>

</html>
