﻿<?php
require('dbconn.php');

$availableBooksResult = $conn->query('SELECT SUM(Quantity) AS `total` FROM catalogue_meta WHERE `Status` = "Available"');
$availableBooks = $availableBooksResult->fetch_assoc();

$borrowedBooksResult = $conn->query('SELECT SUM(Quantity) AS `total` FROM catalogue_meta WHERE `Status` = "Borrowed"');
$borrowedBooks = $borrowedBooksResult->fetch_assoc();

$unavaibaleBooksResult = $conn->query('SELECT SUM(Quantity) AS `total` FROM catalogue JOIN catalogue_meta ON catalogue_meta.CatalogueId = catalogue.CatalogueId WHERE `Status` = "Damaged"');
$unavailableBooks = $unavaibaleBooksResult->fetch_assoc();

$returnedBooksResult = $conn->query('SELECT COUNT(Id) AS `total` FROM records WHERE DateOfIssue IS NOT NULL AND DateOfReturn IS NOT NULL');
$returnedBooks = $returnedBooksResult->fetch_assoc();

$studentsResult = $conn->query('SELECT COUNT(UserId) AS `total`, departments.Department FROM departments LEFT JOIN users ON departments.DepartmentId = users.DepartmentId WHERE `Type` = "student" GROUP BY users.DepartmentId');
$totalNoStudents = 0;
$studentGroups = [];
while ($studentRow = $studentsResult->fetch_assoc()) {
    $totalNoStudents += $studentRow['total'];
    $studentGroups[] = ['label' => $studentRow['Department'], 'data' => [[1, $studentRow['total']]]];
}

$pageTitle = "DASHBOARD";

include('common/access-check.php');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include('common/head.php'); ?>
        <style type="text/css">
            #students-departments-pie-chart {
                height: 400px;
            }
        </style>
    </head>

    <body>
        <?php include('common/top-navbar.php'); ?>

        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php'); ?>

                    <!-- //dashboard area -->
                    <div class="span9">
                        <div class="row-fluid" style="margin-bottom: 20px">
                            <div class="box span3">
                                <div class="card-image">
                                    <img src="/admin/images/book.png" height="50" width="50" />
                                </div>
                                <div class="card-body">
                                    <div class="card-title">Books Available</div>
                                    <p><?php echo $availableBooks['total']; ?></p>
                                </div>
                            </div>

                            <div class="box span3">
                                <div class="card-image">
                                    <img src="/admin/images/borrow.png" height="50" width="50" />
                                </div>
                                <div class="card-body">
                                    <div class="card-title">Borrowed Books</div>
                                    <p><?php echo $borrowedBooks['total']; ?></p>
                                </div>
                            </div>

                            <div class="box span3">
                                <div class="card-image">
                                    <img src="/admin/images/disabled.png" height="50" width="50" />
                                </div>
                                <div class="card-body">
                                    <div class="card-title">Damaged Books</div>
                                    <p><?php echo $unavailableBooks['total']; ?></p>
                                </div>
                            </div>

                            <div class="box span3">
                                <div class="card-image">
                                    <img src="/admin/images/return.png" height="50" width="50" />
                                </div>
                                <div class="card-body">
                                    <div class="card-title">Returned Books</div>
                                    <p><?php echo $returnedBooks['total']; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="row-fluid">
                            <div class="span12">
                                <div class="box">
                                    <div class="card-body">
                                        <div class="card-title">Total Students</div>
                                        <?php echo $totalNoStudents; ?>
                                        <div id="students-departments-pie-chart" class="demo-placeholder"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php'); ?>
        <script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="scripts/flot/jquery.flot.pie.js" type="text/javascript"></script>
        <script type="text/javascript">
            function labelFormatter(label, series) {
        return "<div style='font-size:8pt; text-align:center; padding:2px; color:white;'>" + label + "<br/>" + (series.percent.toFixed(2)) + "% </div>";
    }

            $(document).ready(function () {
                var data = <?php echo json_encode($studentGroups); ?>;
                $.plot('#students-departments-pie-chart', data, {
                    series: {
                        pie: {
                            show: true,
                            radius: 1,
                            label: {
                                show: true,
                                radius: 3/4,
                                formatter: labelFormatter,
                                background: {
                                    opacity: 0.5,
                                    color: '#000'
                                }
                            }
                        }
                    },
                    legend: {
                        show: false
                    }
                });
            });
        </script>
    </body>
</html>