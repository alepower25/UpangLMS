<?php
require('dbconn.php');

include('common/access-check.php');


$bookid=isset($_GET['id1']) ? $conn->real_escape_string($_GET['id1']) : null;
$rollno=isset($_GET['id2']) ? $conn->real_escape_string($_GET['id2']) : null;

if (empty($bookid) || empty($rollno)) {
    http_response_code(422);
    exit;
}

$bookResult = $conn->query('select CatalogueId from catalogue where catalogueId = '. $bookid.' LIMIT 1');
$userResult = $conn->query('select * from users JOIN departments ON departments.DepartmentId = users.DepartmentId where UserId = '. $rollno.' LIMIT 1');

if ($bookResult->num_rows == 0 || $userResult->num_rows == 0) {
    http_response_code(422);
    exit;
}

$row = $userResult->fetch_assoc();

$category=$row['Code'];

/*$sql="select Category from LMS.user where RollNo='$rollno'";
$result=$conn->query($sql);
$row=$result->fetch_assoc();

$category=$row['Category'];*/



/*if($category == 'GEN' || $category == 'OBC' )
{*/

$conn->query("update records set DateOfIssue=curdate(),DueDate=date_add(curdate(),interval 1 day),RenewalsLeft=0 where CatalogueId= ".$bookid." and UserId= ".$rollno);

 
if($conn->affected_rows > 0)
{
    $conn->query('delete from renewals where CatalogueId= '.$bookid.' and UserId= '.$rollno);

 $result=$conn->query("insert into LMS.message (RollNo,Msg,Date,Time,UserId) values ('".$row['RollNo']."','Your request for renewal of BookId: $bookid  has been accepted',curdate(),curtime(), ".$_SESSION['UserId'].")");
echo "<script type='text/javascript'>alert('Success')</script>";
header( "Refresh:0.01; url=renew_requests.php", true, 303);
}
else
{
	echo "<script type='text/javascript'>alert('Error')</script>";
    header( "Refresh:0.01; url=renew_requests.php", true, 303);

}
/*}
else
{$sql2="update LMS.record set Due_Date=date_add(Due_Date,interval 1 day),Renewals_left=0 where BookId='$bookid' and RollNo='$rollno'";

if($conn->query($sql2) === TRUE)
{$sql4="delete from LMS.renew where BookId='$bookid' and RollNo='$rollno'";
 $result=$conn->query($sql4);
 $sql6="insert into LMS.message (RollNo,Msg,Date,Time) values ('$rollno','Your request for renewal of BookId: $bookid has been accepted',curdate(),curtime())";
 $result=$conn->query($sql6);
echo "<script type='text/javascript'>alert('Success')</script>";
header( "Refresh:0.01; url=renew_requests.php", true, 303);
}
else
{
	echo "<script type='text/javascript'>alert('Error')</script>";
    header( "Refresh:0.01; url=renew_requests.php", true, 303);

}
}

*/

?>