<?php
require('dbconn.php');

include('common/header-json.php');
include('common/access-check.php');
include('common/check-error-422.php');

$author = isset($_POST['author']) ? $_POST['author'] : null;

if (empty($author)) {
    http_response_code(422);
    echo json_encode(['errors' => [['key' => 'author', 'val' => 'Author field is required.']], 'message' => 'Please correct the errors found.']);
    exit;
}

$conn->query('INSERT INTO authors (AuthorName) VALUES ("' . $conn->real_escape_string($author) . '")');

if ($conn->affected_rows < 1) {
    http_response_code(422);
    echo json_encode(['message' => 'Unable to insert data into the database.']);
    exit;
}

echo json_encode(['message' => 'Author has been successfully added!', 'data' => ['id' => $conn->insert_id, 'value' => $author]]);