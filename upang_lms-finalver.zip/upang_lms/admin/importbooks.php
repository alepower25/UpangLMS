<?php

require('dbconn.php');

include('common/header-json.php');
include('common/access-check.php');


if (!isset($_FILES['file'])) {
    http_response_code(405);
    exit;
}

$allowedFileTypes = ['csv' => 'text/csv'];
$actualfile = $_FILES['file']['tmp_name'];
$filename = $_FILES['file']['name'];
$filetype = $_FILES['file']['type'];
$filesize = $_FILES['file']['size'];

$extension = pathinfo($filename, PATHINFO_EXTENSION);

if (!array_key_exists($extension, $allowedFileTypes)) {
    http_response_code(422);
    echo json_encode(['message' => 'Please correct the errors found.', 'errors' => [['key' => 'file', 'val' => 'Invalid file format. Only CSV file is allowed.']]]);
    exit;
}

if ($filesize > 52428800) {
    http_response_code(422);
    echo json_encode(['message' => 'Please correct the errors found.', 'errors' => [['key' => 'file', 'val' => 'Exceeded 50MB file size limit.']]]);
    exit;
}

$success = [];
$failure = [];

$file = fopen($actualfile, 'r');
$index = 0;
fgetcsv($file);
while (($data = fgetcsv($file, 10000, ',')) !== FALSE) {

    list($title, $isbn, $authors, $publisher, $year, $type, $categories, $quantity) = $data;

    $title = trim($title);
    $authors = trim($authors);
    $publisher = trim($publisher);
    $year = trim($year);
    $type = trim($type);
    $categories = trim($categories);
    $quantity = trim(intval($quantity));
    $isbn = trim($isbn);

    if (empty($title) || empty($isbn) || empty($authors) || empty($publisher) || empty($year) || empty($type) || empty($categories) || (empty($quantity) || $quantity <= 0)) {
        $failure[] = $index;
        $index++;
        continue;
    }

    $isbn = strtoupper($isbn);

    $publisherResult = $conn->query('SELECT PublisherId FROM Publishers WHERE LOWER(Publisher) = "'. $conn->real_escape_string(strtolower($publisher)).'" LIMIT 1');

    if ($publisherResult->num_rows < 1) {
        $conn->query('INSERT INTO Publishers (Publisher) VALUES ("'.$conn->real_escape_string($publisher).'")');
        $publisherId = $conn->insert_id;
    } else {
        $publisherRow = $publisherResult->fetch_assoc();
        $publisherId = $publisherRow['PublisherId'];
    }

    $typeResult = $conn->query('SELECT TypeId FROM catalogue_types WHERE LOWER(Type) = "'. $conn->real_escape_string(strtolower($type)).'" LIMIT 1');

    if ($typeResult->num_rows < 1) {
        $conn->query('INSERT INTO catalogue_types (Type) VALUES ("'.$conn->real_escape_string($type).'")');
        $typeId = $conn->insert_id;
    } else {
        $typeRow = $typeResult->fetch_assoc();
        $typeId = $typeRow['TypeId'];
    }

    $duplicate = $conn->query('SELECT catalogue.CatalogueId FROM catalogue WHERE UPPER(Isbn) = "'.$conn->real_escape_string($isbn).'"');

    if ($duplicate->num_rows > 0) {
        $bookRow = $duplicate->fetch_assoc();

        $conn->query('UPDATE catalogue_meta SET Quantity = Quantity + '.$conn->real_escape_string($quantity).' WHERE CatalogueId = '.$bookRow['CatalogueId'].' AND `Status` = "Available"');

        if ($conn->affected_rows > 0) {
            $success[] = $index;
        } else {
            $failure[] = $index;
        }

        $index++;
        continue;
    }
    $conn->query('START TRANSACTION');
    $conn->query('INSERT INTO catalogue (Title, Isbn, Year, PublisherId, TypeId)
       VALUES ("'.$conn->real_escape_string($title).'", "'.$conn->real_escape_string($isbn).'", '.$conn->real_escape_string($year).', '.$publisherRow['PublisherId'].', '.$typeRow['TypeId'].')');

    $bookId = $conn->insert_id;

    $conn->query('INSERT INTO catalogue_meta (CatalogueId, Quantity)
       VALUES ('.$bookId.', '.$conn->real_escape_string($quantity).')');

    if ($conn->affected_rows < 1) {
        $conn->query('ROLLBACK');
        $failure[] = $index;
        $index++;
        continue;
    }

    $authorsArray = explode('|', $authors);

    if (count($authorsArray) < 1) {
        $conn->query('ROLLBACK');
        $failure[] = $index;
        $index++;
        continue;
    }

    $authorsResult = $conn->query('SELECT AuthorId FROM authors WHERE LOWER(AuthorName) IN ("'.implode('","', array_map('strtolower', $authorsArray)).'")');

    if ($authorsResult->num_rows < 1) {
        $authorIds = array_map(function ($author) use ($conn) {
            $conn->query('INSERT INTO authors (AuthorName) VALUES ("'.$conn->real_escape_string($author).'")');

            return $conn->insert_id;
        }, $authorsArray);
    } else {
        $authorIds = [];
        while ($authorRow = $authorsResult->fetch_assoc()) {
            $authorIds[] = $authorRow['AuthorId'];
        }
    }

    $authorCatalogueSql = 'INSERT INTO author_catalogue (AuthorId, CatalogueId) VALUES ';
    foreach ($authorIds as $authorId) {
        $authorCatalogueSql .= '('.$authorId.', '.$bookId.') ';
    }
    $conn->query($authorCatalogueSql);
    if ($conn->affected_rows < 1) {
        $conn->query('ROLLBACK');
        $failure[] = $index;
        $index++;
        continue;
    }

    $categoriesArray = explode('|', $categories);

    if (count($categoriesArray) < 1) {
        $conn->query('ROLLBACK');
        $failure[] = $index;
        $index++;
        continue;
    }

    $categoryResult = $conn->query('SELECT CatalogueCatId FROM catalogue_categories WHERE LOWER(Category) IN ("'.implode('","', array_map('strtolower', $categoriesArray)).'")');

    if ($categoryResult->num_rows < 1) {
        $categoryIds = array_map(function ($category) use ($conn) {
            $conn->query('INSERT INTO catalogue_categories (Category) VALUES ("'.$conn->real_escape_string($category).'")');

            return $conn->insert_id;
        }, $categoriesArray);
    } else {
        $categoryIds = [];
        while ($categoryRow = $categoryResult->fetch_assoc()) {
            $categoryIds[] = $categoryRow['CatalogueCatId'];
        }
    }

    $categorySql = 'INSERT INTO catalogue_catalogue_category (CatalogueId, CatalogueCategoryId) VALUES ';
    foreach ($categoryIds as $categoryId) {
        $categorySql .= '('.$bookId.', '.$categoryId.') ';
    }
    $conn->query($categorySql);
    if ($conn->affected_rows < 1) {
        $conn->query('ROLLBACK');
        $failure[] = $index;
        $index++;
        continue;
    }

    $conn->query('COMMIT');
    $success[] = $index;
    $index++;
}

fclose($file);

$countFail = count($failure);
$countSucc = count($success);

$messageType = 'info';

if ($countFail > 0 && $countSucc <= 0) {
    $messageType = 'danger';
}

if ($countSucc > 0 && $countFail <= 0) {
    $messageType = 'success';
}

if ($countFail > 0 && $countSucc > 0) {
    $messageType = 'warning';
}

echo json_encode(['message' => 'There were '.$countFail.' failed imports and '.$countSucc.' successful imports.', 'type' => $messageType]);