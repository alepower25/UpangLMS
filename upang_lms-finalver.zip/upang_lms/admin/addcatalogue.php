<?php
require('dbconn.php');

include('common/access-check.php');

$pageTitle = "Add Catalogue";

if (isset($_POST['submit'])) {
    $errors = [];

    $title = isset($_POST['title']) ? $_POST['title'] : null;
    $authorsArray = isset($_POST['author']) ? $_POST['author'] : [];
    $publisher = isset($_POST['publisher']) ? $_POST['publisher'] : null;
    $year = isset($_POST['year']) ? $_POST['year'] : null;
    $categoryArray = isset($_POST['category']) ? $_POST['category'] : [];
    $type = isset($_POST['type']) ? $_POST['type'] : null;
    $quantity = isset($_POST['quantity']) ? $_POST['quantity'] : 0;

    if (empty($title)) {
        $errors['title'] = 'The title field is required.';
    }

    if (empty($authorsArray)) {
        $errors['authors'] = 'The author field is required.';
    }

    if (empty($publisher)) {
        $errors['publisher'] = 'The publisher field is required.';
    }

    if (empty($year)) {
        $errors['year'] = 'The year field is required.';
    }

    if (empty($category)) {
        $errors['category'] = 'The category field is required.';
    }

    if (empty($type)) {
        $errors['type'] = 'The type field is required.';
    }

    if (empty($quantity) || $quantity === 0) {
        $errors['quantity'] = 'The quantity field is required.';
    }

    $duplicate = $conn->query('SELECT catalogue.CatalogueId FROM catalogue
WHERE `Title` = "'.$conn->real_escape_string($title).'" AND `Year` = '.$conn->real_escape_string($year).' AND PublisherId = '.$conn->real_escape_string($publisher).' AND TypeId = '.$conn->real_escape_string($type));

    if ($duplicate->num_rows > 0) {
        $errors[] = [];
        $message = 'Book already exists! Please add a different book!';
    }

    if (!count($errors)) {
        $conn->query("insert into catalogue (Title,Year,PublisherId,TypeId) values ('".$conn->real_escape_string($title)."', ".$conn->real_escape_string($year).", ".$conn->real_escape_string($publisher).", ".$conn->real_escape_string($type).")");

        if ($conn->affected_rows > 0 ) {
            $catalogue_id = $conn->insert_id;

            // Insert meta
            $conn->query("insert into catalogue_meta (CatalogueId, Quantity) values (".$catalogue_id.", ".$conn->real_escape_string($quantity).")");
            // Insert authors
            $authorsSql = "insert into author_catalogue (AuthorId, CatalogueId) values ";
            foreach($authorsArray as $author_id) {
                $authorsSql .= "(".$conn->real_escape_string($author_id).", ".$catalogue_id."),";
            }
            $conn->query(rtrim($authorsSql, ','));

            // Insert category
            $categoriesSql = "insert into catalogue_catalogue_category (CatalogueId, CatalogueCategoryId) values ";
            foreach($categoryArray as $category_id) {
                $categoriesSql .= "(".$catalogue_id.", ".$conn->real_escape_string($category_id)."),";
            }
            $conn->query($categoriesSql);

            $success = true;

            unset($title);
            unset($authorsArray);
            unset($publisher);
            unset($year);
            unset($category);
            unset($quantity);
            unset($type);
        } else {
            $errors[] = [];
            $message = 'Ooops! Something went wrong!';
        }
    } else {
        $message = isset($message) ? $message : 'Please correct the errors found.';
    }
}

$authors = $conn->query('SELECT * FROM authors ORDER BY AuthorName ASC');
$authorsResults = [];
if ($authors->num_rows > 0 ) {
    while ($row = $authors->fetch_assoc()) {
        $authorsResults[] = $row;
    }
}

$publishers = $conn->query('SELECT * FROM publishers ORDER BY Publisher ASC');
$total_publishers = $publishers->num_rows;

$categories = $conn->query('SELECT * FROM catalogue_categories ORDER BY Category ASC');
$total_categories = $categories->num_rows;

$types = $conn->query('SELECT * FROM catalogue_types ORDER BY TypeId ASC');
$total_types = $types->num_rows;

?>

<!DOCTYPE html>
    <html lang="en">

    <head>
        <?php include('common/head.php'); ?>
        <style type="text/css">
                #field-authors,
                .select-author,
                #field-authors .row-author {
                    margin-bottom: 5px!important;
                }


                .display-block {
                    display: block!important;
                }

                .field-authors-btn,
                .btn-add-author,
                .btn-remove-author {
                    cursor: pointer;
                }

                .btn-add-author:hover,
                .btn-add-publisher:hover,
                .btn-remove-author:hover {
                    text-decoration: none;
                }
        </style>
    </head>

    <body>
        <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php'); ?>
                    <!--/.span9-->
                    <div class="span9">
                        <div class="content">

                            <div class="module">
                                <div class="module-head">
                                    <h3>Add Materials</h3>
                                </div>
                                <div class="module-body" style="padding-top: 30px">
                                    <?php if (isset($errors) && count($errors) > 0) { ?>
                                    <div class="alert alert-danger"><?php echo $message; ?></div>
                                    <?php } ?>

                                    <?php if (isset($success) && $success) {?>
                                    <div class="alert alert-success">Book has been added. Click <a href="/admin/cataloguedetails.php?id=<?php echo $catalogue_id; ?>">here</a> to view.</div>
                                    <?php } ?>
                                    <form class="form-horizontal row-fluid" action="addcatalogue.php" method="post">
                                        <div class="control-group <?php echo isset($errors['title']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="title"><span class="is-required">*</span> <b>Material Title</b></label>
                                            <div class="controls">
                                                <input type="text" id="title" name="title" placeholder="Title" class="span8" value="<?php echo isset($title) ? $title : ''; ?>" required>
                                                <?php if (isset($errors['title'])) { ?>
                                                <span class="help-inline"><?php echo $errors['title']; ?></span>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['author']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="author"><span class="is-required">*</span> <b>Author(s)</b></label>
                                            <div class="controls">
                                                <div id="field-authors">
                                                    <?php if (isset($authorsArray) && count($authorsArray) > 1) {
                                                        foreach ($authorsArray as $author) {
                                                    ?>
                                                    <div class="row-author">
                                                        <select name="author[]" class="span8 select-author">
                                                            <?php
                                                                if (count($authorsResults) > 0) {
                                                                    foreach($authorsResults as $row) {
                                                            ?>
                                                            <option value="<?php echo $row['AuthorId']; ?>" <?php echo ($author === $row['AuthorId']) ? 'selected': ''; ?>><?php echo $row['AuthorName']; ?></option>
                                                            <?php
                                                                    }
                                                                } else {
                                                            ?>
                                                            <option value="" selected>No data available</option>
                                                            <?php }  ?>
                                                        </select>
                                                    </div>
                                                    <?php

                                                        }
                                                    } else {
                                                    ?>
                                                    <div class="row-author">
                                                        <select name="author[]" class="span8 select-author">
                                                            <?php
                                                                if (count($authorsResults) > 0) {
                                                                    foreach($authorsResults as $row) {
                                                            ?>
                                                            <option value="<?php echo $row['AuthorId']; ?>" <?php echo (isset($authorsArray) && $authorsArray[0] === $row['AuthorId']) ? 'selected': ''; ?>><?php echo $row['AuthorName']; ?></option>
                                                            <?php
                                                                    }
                                                                } else {
                                                            ?>
                                                            <option value="" selected>No data available</option>
                                                            <?php }  ?>
                                                        </select>
                                                    </div>
                                                <?php } ?>
                                                </div>
                                                <?php if (isset($errors['authors'])) { ?>
                                                <span class="help-inline"><?php echo $errors['authors']; ?></span>
                                                <?php } ?>
                                                <hr/>
                                                <a class="field-authors-btn <?php echo count($authorsResults) ? '' : 'hidden' ?>" >+ Add more authors</a> <br/>
                                                <a href="#modal-add-author" class="add-on btn-add-author" data-toggle="modal">+ Create an Author</a>
                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['publisher']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="publisher"><span class="is-required">*</span> <b>Publisher</b></label>
                                            <div class="controls">

                                                    <select id="publisher" name="publisher" class="span8 select-publisher">
                                                        <?php
                                                            if ($total_publishers > 0) {
                                                                while($row = $publishers->fetch_assoc()) {
                                                        ?>
                                                        <option value="<?php echo $row['PublisherId']; ?>" <?php echo (isset($publisher) && $publisher === $row['PublisherId']) ? 'selected': ''; ?>><?php echo $row['Publisher']; ?></option>
                                                        <?php
                                                                }
                                                            } else {
                                                        ?>
                                                        <option value="" selected>No data available</option>
                                                        <?php }  ?>
                                                    </select>
                                                    <?php if (isset($errors['publisher'])) { ?>
                                                    <span class="help-inline"><?php echo $errors['publisher']; ?></span> <br/>
                                                    <?php } ?>
                                                     <br/>
                                                    <a href="#modal-add-publisher" class="btn-add-publisher" data-toggle="modal">+ Create a Publisher</a>

                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['year']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="year"><span class="is-required">*</span> <b>Year</b></label>
                                            <div class="controls">
                                                <input type="number" id="year" name="year" placeholder="Year" class="span8" value="<?php echo isset($year) ? $year : ''; ?>" required>
                                                <?php if (isset($errors['year'])) { ?>
                                                <span class="help-inline"><?php echo $errors['year']; ?></span>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['type']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="type"><span class="is-required">*</span> <b>Type</b></label>
                                            <div class="controls">
                                                <select id="type" name="type" class="span8 select-type">
                                                    <?php
                                                        if ($total_types > 0) {
                                                            while($row = $types->fetch_assoc()) {
                                                    ?>
                                                    <option value="<?php echo $row['TypeId']; ?>" <?php echo (isset($type) && $type === $row['CatalogueCatId']) ? 'selected': ''; ?>><?php echo $row['Type']; ?></option>
                                                    <?php
                                                            }
                                                        }  ?>
                                                </select> <?php if (isset($errors['type'])) { ?>
                                                    <span class="help-inline"><?php echo $errors['type']; ?></span> <br/>
                                                    <?php } ?> <br/>
                                                <a href="#modal-add-type" class="btn-add-type" data-toggle="modal">+ Create a Type</a>
                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['category']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="category"><span class="is-required">*</span> <b>Categories</b></label>
                                            <div class="controls">
                                                <select id="category" name="category" multiple class="span8 select-category">
                                                    <?php
                                                        if ($total_categories > 0) {
                                                            while($row = $categories->fetch_assoc()) {
                                                    ?>
                                                    <option value="<?php echo $row['CatalogueCatId']; ?>" <?php echo (isset($category) && $category === $row['CatalogueCatId']) ? 'selected': ''; ?>><?php echo $row['Category']; ?></option>
                                                    <?php
                                                            }
                                                        }
                                                         ?>
                                                </select> <?php if (isset($errors['category'])) { ?>
                                                    <span class="help-inline"><?php echo $errors['category']; ?></span> <br/>
                                                    <?php } ?> <br/>
                                                <a href="#modal-add-category" class="btn-add-category" data-toggle="modal">+ Create a Category</a>
                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['quantity']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="quantity"><b>Quantity</b></label>
                                            <div class="controls">
                                                <input type="number" id="availability" name="quantity" placeholder="Number of Copies" class="span8" value="<?php echo isset($quantity) ? $quantity : 1; ?>" required>
                                                <?php if (isset($errors['quantity'])) { ?>
                                                    <span class="help-inline"><?php echo $errors['quantity']; ?></span>
                                                    <?php } ?>
                                            </div>
                                        </div>


                                        <div class="control-group">
                                            <div class="controls">
                                                <button type="submit" name="submit" class="btn">Add Materials</button> <span>or</span>
                                                <a href="importcatalogue.php" class="btn btn-link">Import Materials</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>



                        </div>
                        <!--/.content-->
                    </div>

                </div>
            </div>
            <!--/.container-->

        </div>

        <?php include('common/footer.php'); ?>

        <?php include('common/modal-add-author.php'); ?>
        <?php include('common/modal-add-publisher.php'); ?>
        <?php include('common/modal-add-category.php'); ?>
        <?php include('common/modal-add-type.php'); ?>
        <?php include('modal-import.php'); ?>

        <script type="text/javascript">
            $(document).ready(function () {
                var $fieldAuthors = $('#field-authors');

                $('.field-authors-btn').on('click', function (e) {
                    e.preventDefault();
                    var $firstSelectAuthor = $fieldAuthors.find('.row-author:last-child .select-author');
                    $firstSelectAuthor.select2('destroy');
                    var $clonedAuthorSelect = $firstSelectAuthor.clone();
                    var $removeAuthorSelect = $('<div class="row-author display-block"> <a class=" btn-remove-author">- Remove this author</a></div>')
                    $removeAuthorSelect.prepend($clonedAuthorSelect);

                    $fieldAuthors.append($removeAuthorSelect);

                    $('select').select2({
                        theme: 'bootstrap'
                    });
                });

                $(document).delegate('.btn-remove-author', 'click', function (e) {
                    e.preventDefault();
                    $(e.currentTarget).parent().remove();
                });
            });
        </script>
    </body>

</html>
