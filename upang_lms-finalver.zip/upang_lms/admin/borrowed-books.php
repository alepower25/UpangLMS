<?php
require('dbconn.php');

$availableBooksResult = $conn->query('SELECT * FROM records JOIN catalogue ON catalogue.CatalogueId = records.CatalogueId WHERE DateOfIssue IS NOT NULL ORDER BY catalogue.CatalogueId ASC');


$pageTitle = "Borrowed Books";

include('common/access-check.php');
?>
<!DOCTYPE html>
    <html lang="en">

    <head>
         <?php include('common/head.php'); ?>
         <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
         <style type="text/css">
             .dt-buttons {
                float: left!important;
                margin-left: 12%!important;
             }

             .calendar-table .table-condensed th,
             .calendar-table .table-condensed td {
                padding: 0!important;
             }

             .datatable-2 {
                width: 100%!important;
             }
         </style>
    </head>

    <body>
        <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php'); ?>

                    <div class="span9">
                            <div class="row-fluid">
                                <div class="pull-right"><label style="display: inline-block; vertical-align: middle; margin-right: 5px">Select date range:</label><div class="input-append date dp-container"> <input type="text" placeholder="Select date"><span class="add-on"><i class="icon-calendar"></i></span></div> <button name="clear" style="vertical-align: top;" type="button" disabled class="btn btn-default">Clear</button></div>
                            </div>
                            <table class="table datatable-2" id="tables">
                                <thead>
                                    <tr>
                                        <th>Book id</th>
                                        <th>Title</th>
                                        <th>ISBN</th>
                                        <th>Issued Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    if ($availableBooksResult->num_rows) {
                                        while ($row = $availableBooksResult->fetch_assoc()) {
                                ?>
                                        <tr>
                                            <td><?php echo $row['CatalogueId']; ?></td>
                                            <td><?php echo $row['Title']; ?></td>
                                            <td><?php echo $row['Isbn']; ?></td>
                                            <td><?php echo $row['DateOfIssue']; ?></td>
                                            <td>Borrowed</td>
                                        </tr>
                                <?php
                                        }
                                    }
                                ?>
                                </tbody>
                            </table>
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php'); ?>

        <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
        <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
        <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
        <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/datetime/1.4.0/js/dataTables.dateTime.min.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
        <script type="text/javascript">
            var minDate, maxDate;

            $.fn.dataTable.ext.search.push(
                function( settings, data, dataIndex ) {
                    var dtpickerval = $('.input-append.date input').val();
                    if (dtpickerval === '') {
                        $('[name="clear"]').prop('disabled', true);
                        return true;
                    }

                    $('[name="clear"]').prop('disabled', false);
                    var dtsplit = dtpickerval.split(' - ');

                    var min =  moment(dtsplit[0], 'MM/DD/YYYY');
                    var max = moment(dtsplit[1], 'MM/DD/YYYY');
                    var date = new Date( data[3] );

                    if (
                        ( min === null && max === null ) ||
                        ( min === null && date <= max ) ||
                        ( min <= date   && max === null ) ||
                        ( min <= date   && date <= max )
                    ) {
                        return true;
                    }
                    return false;
                }
            );

            $(document).ready(function() {

                var dt = $('.datatable-2').DataTable( {
                    lengthMenu: [500, 1000, 5000, 10000],
                    language: {
                        searchPlaceholder: 'Enter Book Name/Book Id/ISBN'
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'pdf',
                            text: 'Export to PDF',
                            className: 'btn btn-default'
                        },
                        {
                            extend: 'print',
                            className: 'btn btn-default',
                            messageTop: function () {
                                return '<h3>Date Range: '+$('.input-append.date input').val()+'</h3>';
                            }
                        }
                    ],
                    columnDefs: [
                        {
                            targets: [3],
                            visible: false
                        }
                    ]
                } );

                $('.input-append.date input').daterangepicker({
                    showDropdowns: true,
                    ranges: {
                        'Today': [moment(), moment()],
                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                    },
                    opens: 'left',
                    autoUpdateInput: false,
                });

                $('.input-append.date input').on('apply.daterangepicker', function(ev, picker) {
                    $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));

                    dt.draw();
                });

                $('[name="clear"]').on('click', function() {
                    $('.input-append.date input').val('');
                    dt.draw();
                })
                $('.dataTables_paginate').addClass('btn-group datatable-pagination');
                $('.dataTables_paginate > a').wrapInner('<span />');
                $('.dataTables_paginate > a:first-child').append('<i class="icon-chevron-left shaded"></i>');
                $('.dataTables_paginate > a:last-child').append('<i class="icon-chevron-right shaded"></i>');
            } );
        </script>
    </body>

    </html>