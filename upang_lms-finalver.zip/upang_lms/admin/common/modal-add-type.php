<div id="modal-add-type" class="modal hide fade">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h3>Create Type</h3>
  </div>
  <div class="modal-body">
    <?php include('form-type.php'); ?>
  </div>
  <div class="modal-footer">
    <a href="#" class="btn" data-dismiss="modal">Cancel</a>
    <button type="button" class="btn btn-info btn-submit-type-add">Create</button>
  </div>
</div>

<script type="text/javascript">
  $(document).ready(function () {
    var $modalAddType = $('#modal-add-type');
    var $formPublisher = $('#form-type');

    $(document).delegate('.btn-submit-type-add', 'click', function (e) {
      var $btn = $(e.currentTarget);

      $.ajax({
        url: $formPublisher.prop('action'),
        method: $formPublisher.prop('method'),
        dataType: 'json',
        beforeSend: function () {
          $btn.prop('disabled', true);
          $modalAddType.find('.alert').remove();
          $modalAddType.find('.error .help-inline').remove();
          $modalAddType.find('.error').removeClass('error');
          $modalAddType.append('<div class="loader"><span>Loading...</span></div>');
        },
        data: $formPublisher.serialize() + '&submit',
        error: function (err) {
          var response = $.parseJSON(err.responseText);

          $formPublisher.prepend('<div class="alert alert-danger">'+response.message+'</div>');

          if (!response.hasOwnProperty('errors')) {
            return;
          }

          $.each(response.errors, function (index, value) {
            var $inputEl = $('#input-' + value.key);
            $inputEl.parent('.control-group').addClass('error');
            $('<span class="help-inline">'+value.val+'</span>').insertAfter($inputEl);
          });
        },
        success: function (response) {
          var $selectAuthor = $('.select-type');

          $formPublisher[0].reset();
          $formPublisher.prepend('<div class="alert alert-success">'+response.message+'</div>');

          if ($selectAuthor.find('option')[0].value === '') {
            $selectAuthor.find('option')[0].remove();
          }

          $selectAuthor.append('<option value="'+ response.data.id+'">'+ response.data.value+'</option>');
          $('.field-type-btn').show();

        },
        complete: function () {
          $btn.prop('disabled', false);
          $('.loader').remove();
        }
      });
    });


    $modalAddType.on('hide', function () {
      $formPublisher[0].reset();
      $modalAddType.find('.alert').remove();
      $modalAddType.find('.error .help-inline').remove();
      $modalAddType.find('.error').removeClass('error');
    })
  });
</script>