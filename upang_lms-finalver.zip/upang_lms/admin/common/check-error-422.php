<?php

if (!isset($_POST['submit'])) {
    http_response_code(405);
    exit;
}
