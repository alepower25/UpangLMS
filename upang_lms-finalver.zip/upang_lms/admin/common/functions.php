<?php
date_default_timezone_set ('Asia/Manila');

function compute_penalty ($dueDate, $rate = 5) {
    $due = new DateTime($dueDate);
    $due->modify('+24 hours');

    $now = new DateTime();

    if ($now < $due) {
        return 0;
    }

    $diff = $now->diff($due);

    return ($diff->h + $diff->days * 24)  * $rate;
}

function is_nav_active($page) {
    $current_url_array = explode('/', $_SERVER['REQUEST_URI']);

    return $page === explode('?', end($current_url_array))[0];
}