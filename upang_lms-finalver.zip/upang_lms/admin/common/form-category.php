<form id="form-category" class="form-inline" method="post" action="addcategory.php">
    <div class="control-group">
        <label>Category:</label> <input class="span3" id="input-category" type="text" name="category" required />
    </div>
</form>