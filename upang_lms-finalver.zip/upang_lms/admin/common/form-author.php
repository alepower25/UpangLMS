<form id="form-author" class="form-inline" method="post" action="addauthor.php">
    <div class="control-group">
        <label>Author Name:</label> <input class="span3" id="input-author" type="text" name="author" required />
    </div>
</form>