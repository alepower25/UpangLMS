<?php  if (!isset($_SESSION['RollNo'])) { ?>
    <script type='text/javascript'>alert('Access Denied!!!')</script>
<?php exit;
}
?>

<?php  if (isset($_SESSION['Type']) && $_SESSION['Type'] !== 'admin') { ?>
    <script type='text/javascript'>alert('Access Denied!!!')</script>
<?php exit;
}
?>