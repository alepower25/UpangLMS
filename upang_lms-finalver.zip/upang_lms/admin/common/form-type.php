<form id="form-type" class="form-inline" method="post" action="addtype.php">
    <div class="control-group">
        <label>Type:</label> <input class="span3" id="input-type" type="text" name="type" required />
    </div>
</form>