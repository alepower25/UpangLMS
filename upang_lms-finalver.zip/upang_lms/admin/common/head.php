<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($pageTitle) ? $pageTitle : 'LMS'; ?></title>
<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
<link type="text/css" href="css/theme.css" rel="stylesheet">
<link type="text/css" href="css/select2.min.css" rel="stylesheet">
<link type="text/css" href="css/select2-bootstrap.min.css" rel="stylesheet">
<link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
<link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
<style>
    .dropbtn {
        background-color: #447546;
        color: white;
        padding: 20px;
        font-size: 12px;
        border: none;
        line-height: 20px;
        display: block;
        text-align: left;
        width: 100%;
    }

    .dropdown {
        position: relative;
        display: block;
    }

    .dropdown-content {
        display: none;
        background-color: #447546;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
        z-index: 1;
    }

    .dropdown-content a {
        color: white;
        padding: 12px 16px 12px 35px;
        border: 1px solid white;
        text-decoration: none;
        display: block;
    }

    .dropdown-content a:hover {
        background-color: #b38600;
    }

    .widget-menu>li.active .dropdown-content,
    .dropdown:hover .dropdown-content {
        display: block;
    }

    .dropdown:hover .dropbtn {
        background-color: #b38600;
    }

    .is-required {
        color: red;
    }

    .loader {
        position: absolute;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0, 0.3);
        top: 0;
        color: #fff;
        font-size: 30px;
        text-align: center;
        vertical-align: middle;
    }

    .loader span {
        position: relative;
        top: 50%;
    }

    .select2-selection__choice__remove {
        border: 0 none;
        background: none;
    }

    .select2-search__field {
        box-shadow: unset!important;
    }

    .select2-container--bootstrap .select2-selection--multiple .select2-search--inline .select2-search__field {
        padding-bottom: 6px;
        padding-top: 6px;
    }

    .dataTables_wrapper .select2-container--bootstrap {
        display: inline-block;
    }

    .dataTables_length select {
        width: 100px;
    }
</style>