<div class="span3">
    <div class="sidebar">
        <ul class="widget widget-menu unstyled">
            <li <?php if (is_nav_active('index.php')) { ?>class="active"<?php } ?>><a href="index.php"><i class="menu-icon icon-home"></i>Dashboard
                </a></li>
            </li>
            <li <?php if (is_nav_active('book.php') || is_nav_active('addbook.php') || is_nav_active('bookdetails.php') || is_nav_active('edit_bookdetails.php')) { ?>class="active"<?php } ?>>
                <div class="dropdown">
                    <button class="dropbtn"><i class="menu-icon icon-book"></i>Book Management</button>
                    <div class="dropdown-content">
                        <a <?php if (is_nav_active('book.php')) { ?>class="active"<?php } ?> href="book.php"><i class="icon-caret-right"></i> All Books</a>
                        <a <?php if (is_nav_active('addbook.php')) { ?>class="active"<?php } ?> href="addbook.php"><i class="icon-caret-right"></i> Add Materials</a>
                    </div>
                </div>
            </li>
            <li <?php if (is_nav_active('current.php') || is_nav_active('issue_requests.php') || is_nav_active('renew_requests.php') || is_nav_active('return_requests.php')) { ?>class="active"<?php } ?>>
                <div class="dropdown">
                    <button class="dropbtn"><i class="menu-icon icon-list"></i>Transaction Management</button>
                    <div class="dropdown-content">
                        <a <?php if (is_nav_active('current.php')) { ?>class="active"<?php } ?> href="current.php"><i class="icon-caret-right"></i> Advanced Search</a>
                        <a <?php if (is_nav_active('issue_requests.php')) { ?>class="active"<?php } ?> href="issue_requests.php"><i class="icon-caret-right"></i> Issue Request</a>
                        <a <?php if (is_nav_active('renew_requests.php')) { ?>class="active"<?php } ?> href="renew_requests.php"><i class="icon-caret-right"></i> Renew Request</a>
                        <a <?php if (is_nav_active('return_requests.php')) { ?>class="active"<?php } ?> href="return_requests.php"> <i class="icon-caret-right"></i> Return Request</a>
                    </div>
                </div>
            </li>

            <li <?php if (is_nav_active('total-books.php') || is_nav_active('borrowed-books.php') || is_nav_active('unavailable-books.php') || is_nav_active('student_report.php')) { ?>class="active"<?php } ?>>
                <div class="dropdown">
                    <button class="dropbtn"><i class="menu-icon icon-list"></i>Report Management</button>
                    <div class="dropdown-content">
                        <a <?php if (is_nav_active('total-books.php')) { ?>class="active"<?php } ?>  href="total-books.php"><i class="icon-caret-right"></i> Books Available</a>
                        <a <?php if (is_nav_active('borrowed-books.php')) { ?>class="active"<?php } ?>  href="borrowed-books.php"><i class="icon-caret-right"></i> Borrowed Books</a>
                        <a <?php if (is_nav_active('unavailable-books.php')) { ?>class="active"<?php } ?> href="unavailable-books.php"><i class="icon-caret-right"></i> Unavailable Books</a>
                        <a <?php if (is_nav_active('student_report.php')) { ?>class="active"<?php } ?> href="student_report.php"><i class="icon-caret-right"></i> Total Students</a>
                    </div>
                </div>
            </li>
            <li <?php if (is_nav_active('student.php')) { ?>class="active"<?php } ?>><a href="student.php"><i class="menu-icon icon-user"></i>User Management </a>
            </li>
        </ul>
        <ul class="widget widget-menu unstyled">
        </ul>
    </div>
    <!--/.sidebar-->
</div>
<!--/.span3-->