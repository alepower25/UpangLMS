<form id="form-publisher" class="form-inline" method="post" action="addpublisher.php">
    <div class="control-group">
        <label>Publisher Name:</label> <input class="span3" id="input-publisher" type="text" name="publisher" required />
    </div>
</form>