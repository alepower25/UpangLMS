<div id="modal-add-category" class="modal hide fade">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h3>Create Category</h3>
  </div>
  <div class="modal-body">
    <?php include('form-category.php'); ?>
  </div>
  <div class="modal-footer">
    <a href="#" class="btn" data-dismiss="modal">Cancel</a>
    <button type="button" class="btn btn-info btn-submit-category-add">Create</button>
  </div>
</div>

<script type="text/javascript">
  $(document).ready(function () {
    var $modalAddAuthor = $('#modal-add-category');
    var $formPublisher = $('#form-category');

    $(document).delegate('.btn-submit-category-add', 'click', function (e) {
      var $btn = $(e.currentTarget);

      $.ajax({
        url: $formPublisher.prop('action'),
        method: $formPublisher.prop('method'),
        dataType: 'json',
        beforeSend: function () {
          $btn.prop('disabled', true);
          $modalAddAuthor.find('.alert').remove();
          $modalAddAuthor.find('.error .help-inline').remove();
          $modalAddAuthor.find('.error').removeClass('error');
          $modalAddAuthor.append('<div class="loader"><span>Loading...</span></div>');
        },
        data: $formPublisher.serialize() + '&submit',
        error: function (err) {
          var response = $.parseJSON(err.responseText);

          $formPublisher.prepend('<div class="alert alert-danger">'+response.message+'</div>');

          if (!response.hasOwnProperty('errors')) {
            return;
          }

          $.each(response.errors, function (index, value) {
            var $inputEl = $('#input-' + value.key);
            $inputEl.parent('.control-group').addClass('error');
            $('<span class="help-inline">'+value.val+'</span>').insertAfter($inputEl);
          });
        },
        success: function (response) {
          var $selectAuthor = $('.select-category');

          $formPublisher[0].reset();
          $formPublisher.prepend('<div class="alert alert-success">'+response.message+'</div>');

          if ($selectAuthor.find('option')[0].value === '') {
            $selectAuthor.find('option')[0].remove();
          }

          $selectAuthor.append('<option value="'+ response.data.id+'">'+ response.data.value+'</option>');
          $('.field-category-btn').show();

        },
        complete: function () {
          $btn.prop('disabled', false);
          $('.loader').remove();
        }
      });
    });


    $modalAddAuthor.on('hide', function () {
      $formPublisher[0].reset();
      $modalAddAuthor.find('.alert').remove();
      $modalAddAuthor.find('.error .help-inline').remove();
      $modalAddAuthor.find('.error').removeClass('error');
    })
  });
</script>