<?php
require('dbconn.php');

include('common/access-check.php');

$bookid=isset($_GET['id1']) ? $conn->real_escape_string($_GET['id1']) : null;
$rollno=isset($_GET['id2']) ? $conn->real_escape_string($_GET['id2']) : null;

if (empty($bookid) || empty($rollno)) {
    http_response_code(422);
    exit;
}

// Validate user Id and book id
$bookResult = $conn->query('select CatalogueId from catalogue where catalogueId = '. $bookid.' LIMIT 1');
$userResult = $conn->query('select * from users JOIN departments ON departments.DepartmentId = users.DepartmentId where UserId = '. $rollno.' LIMIT 1');

if ($bookResult->num_rows == 0 || $userResult->num_rows == 0) {
    http_response_code(422);
    exit;
}

$row = $userResult->fetch_assoc();

$category=$row['Code'];



/*if($category == 'GEN' || $category == 'OBC' )
{*/
    $conn->query("update records set DateOfIssue=curdate(),DueDate=date_add(curdate(),interval 1 day),RenewalsLeft=1 where CatalogueId='$bookid' and UserId='$rollno'");

    if($conn->affected_rows > 0)
    {

        $conn->query('update catalogue_meta SET Quantity = Quantity - 1 WHERE CatalogueId = '. $bookid. ' AND `Status` = "Available"');
        $conn->query('update catalogue_meta SET Quantity = Quantity + 1 WHERE CatalogueId = '. $bookid. ' AND `Status` = "Borrowed"');

     $conn->query("insert into LMS.message (RollNo,Msg,Date,Time,UserId) values ('".$row['RollNo']."','Your request for issue of BookId: ".$bookid."  has been accepted',curdate(),curtime(), ".$_SESSION['UserId'].")");

    echo "<script type='text/javascript'>alert('Success')</script>";
    header( "Refresh:0.01; url=issue_requests.php", true, 303);
    }
    else
    {
    	echo "<script type='text/javascript'>alert('Error')</script>";
        header( "Refresh:1; url=issue_requests.php", true, 303);

    }
/*}
else
{$sql2="update LMS.record set Date_of_Issue=curdate(),Due_Date=date_add(curdate(),interval 1 day),Renewals_left=1 where BookId='$bookid' and RollNo='$rollno'";

if($conn->query($sql2) === TRUE)
{$sql4="update LMS.book set Availability=Availability-1 where BookId='$bookid'";
 $result=$conn->query($sql4);
 $sql6="insert into LMS.message (RollNo,Msg,Date,Time) values ('$rollno','Your request for issue of BookId: $bookid has been accepted',curdate(),curtime())";
 $result=$conn->query($sql6);
echo "<script type='text/javascript'>alert('Success')</script>";
header( "Refresh:1; url=issue_requests.php", true, 303);
}
else
{
	echo "<script type='text/javascript'>alert('Error')</script>";
    header( "Refresh:1; url=issue_requests.php", true, 303);

}
}*/



?>