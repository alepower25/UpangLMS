<?php
require('dbconn.php');

include('common/access-check.php');

if (isset($_POST['submit'])) {
    $rollno = isset($_POST['RollNo']) ? $conn->real_escape_string(trim($_POST['RollNo'])) : '';
    $messageContent = isset($_POST['Message']) ? $conn->real_escape_string(trim($_POST['Message'])) : '';
    $errors = [];

    if (empty($rollno)) {
        $errors['rollno'] = 'The Student No. field is required.';
    }

    if (empty($messageContent)) {
        $errors['message'] = 'The Message field is required.';
    }

    $studentResult = $conn->query('select UserId from users where RollNo = "'.$rollno.'"');

    if ($studentResult->num_rows == 0) {
        $errors['rollno'] = 'Student Number doesn\'t exists!';
    }

    if (!count($errors)) {
        $studentRow = $studentResult->fetch_assoc();
        $conn->query('insert into message (RollNo,Msg,Date,Time, UserId) values ("'.$rollno.'","'.$messageContent.'",curdate(),curtime(), '.$studentRow['UserId'].')');

        if ($conn->affected_rows > 0) {
            $success = true;

            unset($rollno);
            unset($messageContent);
        } else { //echo $conn->error;
            echo "<script type='text/javascript'>alert('Error')</script>";
        }
    } else {
        $message = isset($message) ? $message : 'Please correct the errors found.';
    }
}

?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <?php include('common/head.php') ?>
    </head>

    <body>
       <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php'); ?>

                    <div class="span9">
                        <div class="content">

                            <div class="module">
                                <div class="module-head">
                                    <h3>Send a message</h3>
                                </div>
                                <div class="module-body">
                                    <?php if (isset($errors) && count($errors) > 0) { ?>
                                        <div class="alert alert-danger"><?php echo $message; ?></div>
                                        <?php } ?>

                                        <?php if (isset($success) && $success) {?>
                                        <div class="alert alert-success">Message has been sent!</div>
                                        <?php } ?>
                                    <br>

                                    <form class="form-horizontal row-fluid" action="message.php" method="post">

                                        <div class="control-group <?php echo isset($errors['rollno']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="Rollno"><b>Student No:</b></label>
                                            <div class="controls">
                                                <input type="text" id="RollNo" name="RollNo" placeholder="Student Number" class="span8" required>
                                                <?php if (isset($errors['rollno'])) { ?>
                                                <span class="help-inline"><?php echo $errors['rollno']; ?></span>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['message']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="Message"><b>Message:</b></label>
                                            <div class="controls">
                                                <textarea id="Message" name="Message" placeholder="Enter Message" class="span8" required></textarea>
                                                <?php if (isset($errors['message'])) { ?>
                                                <span class="help-inline"><?php echo $errors['message']; ?></span>
                                                <?php } ?>
                                            </div>
                                            <hr>
                                            <div class="control-group">
                                                <div class="controls">
                                                    <button type="submit" name="submit" class="btn">Send Message</button>
                                                </div>
                                            </div>
                                    </form>
                                </div>
                            </div>



                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php'); ?>
    </body>

    </html>
