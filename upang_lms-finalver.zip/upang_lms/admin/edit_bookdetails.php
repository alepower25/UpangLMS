<?php
require('dbconn.php');

include('common/access-check.php');

if (!isset($_GET['id']) || !is_integer(intval($_GET['id']))) {
    http_response_code(403);
    exit;
}

$result = $conn->query('SELECT catalogue.*  FROM catalogue JOIN catalogue_types ON catalogue_types.TypeId = catalogue.TypeId JOIN publishers ON publishers.PublisherId = catalogue.PublisherId WHERE CatalogueId = '. $conn->real_escape_string($_GET['id']));

if ($result->num_rows < 1) {
    http_response_code(404);
    exit;
}

$book = $result->fetch_assoc();

$authorsIdsResult = $conn->query('SELECT AuthorId FROM author_catalogue WHERE CatalogueId = '. $book['CatalogueId']);

$authorIds = [];
while ($authorsIdsRow = $authorsIdsResult->fetch_assoc()) {
    $authorIds[] = $authorsIdsRow['AuthorId'];
}

$categoryIdsResult = $conn->query('SELECT CatalogueCategoryId FROM catalogue_catalogue_category WHERE CatalogueId = '. $book['CatalogueId']);

$categoryIds = [];
while ($categoryIdsRow = $categoryIdsResult->fetch_assoc()) {
    $categoryIds[] = $categoryIdsRow['CatalogueCategoryId'];
}

$metaResult = $conn->query('SELECT Status, Quantity FROM catalogue_meta WHERE CatalogueId = '. $book['CatalogueId']);
$availability = [];
while($metaRow = $metaResult->fetch_assoc()) {
    $availability[$metaRow['Status']] = $metaRow;
}

$isbn = isset($_POST['isbn']) ? strtoupper(trim($_POST['isbn'])) : $book['Isbn'];
$title = isset($_POST['title']) ? trim($_POST['title']) : $book['Title'];
$authorsArray = isset($_POST['author']) ? $_POST['author'] : $authorIds;
$publisher = isset($_POST['publisher']) ? trim($_POST['publisher']) : $book['PublisherId'];
$year = isset($_POST['year']) ? trim($_POST['year']) : $book['Year'];
$categoryArray = isset($_POST['category']) ? $_POST['category'] : $categoryIds;
$type = isset($_POST['type']) ? trim($_POST['type']) : $book['TypeId'];
$quantity = isset($_POST['quantity']) ? trim($_POST['quantity']) : $availability['Available']['Quantity'];

$pageTitle = "Edit: ". $book['Title'];

if (isset($_POST['submit'])) {
    $errors = [];

    if (empty($isbn)) {
        $errors['isbn'] = 'The ISBN field is required.';
    }

    if (empty($title)) {
        $errors['title'] = 'The title field is required.';
    }

    if (empty($authorsArray)) {
        $errors['authors'] = 'The author field is required.';
    }

    if (empty($publisher)) {
        $errors['publisher'] = 'The publisher field is required.';
    }

    if (empty($year)) {
        $errors['year'] = 'The year field is required.';
    }

    if (empty($categoryArray)) {
        $errors['category'] = 'The category field is required.';
    }

    if (empty($type)) {
        $errors['type'] = 'The type field is required.';
    }

    if (empty($quantity) || $quantity <= 0) {
        $errors['quantity'] = ' The quantity field should be a positive integer number.';
    }

    $duplicate = $conn->query('SELECT catalogue.CatalogueId FROM catalogue WHERE UPPER(Isbn) = "'.$conn->real_escape_string($isbn).'" AND CatalogueId != '.$book['CatalogueId']);

    if ($duplicate->num_rows > 0) {
        $errors['isbn'] = 'The ISBN should be unique.';
        $message = 'Book already exists! Please update a different book!';
    }

    if (!count($errors)) {
        $conn->query("UPDATE catalogue SET Title = '".$conn->real_escape_string($title)."', Year = ".$conn->real_escape_string($year).", PublisherId = ".$conn->real_escape_string($publisher).", TypeId = ".$conn->real_escape_string($type)." WHERE CatalogueId = ". $book['CatalogueId']);


            $catalogue_id = $book['CatalogueId'];

            // Insert meta
            $conn->query("UPDATE catalogue_meta SET Quantity = ".$conn->real_escape_string($quantity)." WHERE `Status` = 'Available' AND CatalogueId = ".$catalogue_id);
            // Insert authors
            $conn->query('DELETE FROM author_catalogue WHERE CatalogueId = '. $catalogue_id);
            $authorsSql = "insert into author_catalogue (AuthorId, CatalogueId) values ";
            foreach($authorsArray as $author_id) {
                $authorsSql .= "(".$conn->real_escape_string($author_id).", ".$catalogue_id."),";
            }
            $conn->query(rtrim($authorsSql, ','));

            // Insert category
            $conn->query('DELETE FROM catalogue_catalogue_category WHERE CatalogueId = '. $catalogue_id);
            $categoriesSql = "insert into catalogue_catalogue_category (CatalogueId, CatalogueCategoryId) values ";
            foreach($categoryArray as $category_id) {
                $categoriesSql .= "(".$catalogue_id.", ".$conn->real_escape_string($category_id)."),";
            }
            $conn->query(rtrim($categoriesSql, ','));

            $success = true;
    } else {
        $message = isset($message) ? $message : 'Please correct the errors found.';
    }
}

$authors = $conn->query('SELECT * FROM authors ORDER BY AuthorName ASC');
$authorsResults = [];
if ($authors->num_rows > 0 ) {
    while ($row = $authors->fetch_assoc()) {
        $authorsResults[] = $row;
    }
}

$publishers = $conn->query('SELECT * FROM publishers ORDER BY Publisher ASC');
$total_publishers = $publishers->num_rows;

$categories = $conn->query('SELECT * FROM catalogue_categories ORDER BY Category ASC');
$total_categories = $categories->num_rows;

$types = $conn->query('SELECT * FROM catalogue_types ORDER BY TypeId ASC');
$total_types = $types->num_rows;
?>
<!DOCTYPE html>
    <html lang="en">

    <head>
        <?php include('common/head.php'); ?>
        <style type="text/css">
                #field-authors,
                .select-author,
                #field-authors .row-author {
                    margin-bottom: 5px!important;
                }


                .display-block {
                    display: block!important;
                }

                .field-authors-btn,
                .btn-add-author,
                .btn-remove-author {
                    cursor: pointer;
                }

                .btn-add-author:hover,
                .btn-add-publisher:hover,
                .btn-remove-author:hover {
                    text-decoration: none;
                }
        </style>
    </head>

    <body>
         <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php'); ?>

                    <div class="span9">
                        <div class="module">
                            <div class="module-head">
                                <h3>Update Book Details</h3>
                            </div>
                            <div class="module-body" style="padding-top: 30px">
                                    <?php if (isset($errors) && count($errors) > 0) { ?>
                                    <div class="alert alert-danger"><?php echo $message; ?></div>
                                    <?php } ?>

                                    <?php if (isset($success) && $success) {?>
                                    <div class="alert alert-success">Book has been updated. Click <a href="/admin/bookdetails.php?id=<?php echo $catalogue_id; ?>">here</a> to view.</div>
                                    <?php } ?>
                                    <form class="form-horizontal row-fluid" action="edit_bookdetails.php?id=<?php echo $book['CatalogueId']; ?>" method="post">
                                        <input type="hidden" name="id" value="<?php echo $book['CatalogueId']; ?>">
                                        <div class="control-group <?php echo isset($errors['isbn']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="isbn"><span class="is-required">*</span> <b>ISBN</b></label>
                                            <div class="controls">
                                                <input type="text" id="isbn" name="isbn" placeholder="ISBN" class="span8" value="<?php echo isset($isbn) ? $isbn : ''; ?>" required>
                                                <?php if (isset($errors['isbn'])) { ?>
                                                <span class="help-inline"><?php echo $errors['isbn']; ?></span>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['title']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="title"><span class="is-required">*</span> <b>Material Title</b></label>
                                            <div class="controls">
                                                <input type="text" id="title" name="title" placeholder="Title" class="span8" value="<?php echo isset($title) ? $title : ''; ?>" required>
                                                <?php if (isset($errors['title'])) { ?>
                                                <span class="help-inline"><?php echo $errors['title']; ?></span>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['author']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="author"><span class="is-required">*</span> <b>Author(s)</b></label>
                                            <div class="controls">
                                                <div id="field-authors">
                                                    <?php if (isset($authorsArray) && count($authorsArray) > 1) {
                                                        foreach ($authorsArray as $author) {
                                                    ?>
                                                    <div class="row-author">
                                                        <select name="author[]" class="span8 select-author">
                                                            <?php
                                                                if (count($authorsResults) > 0) {
                                                                    foreach($authorsResults as $row) {
                                                            ?>
                                                            <option value="<?php echo $row['AuthorId']; ?>" <?php echo ($author === $row['AuthorId']) ? 'selected': ''; ?>><?php echo $row['AuthorName']; ?></option>
                                                            <?php
                                                                    }
                                                                } else {
                                                            ?>
                                                            <option value="" selected>No data available</option>
                                                            <?php }  ?>
                                                        </select>
                                                    </div>
                                                    <?php

                                                        }
                                                    } else {
                                                    ?>
                                                    <div class="row-author">
                                                        <select name="author[]" class="span8 select-author">
                                                            <?php
                                                                if (count($authorsResults) > 0) {
                                                                    foreach($authorsResults as $row) {
                                                            ?>
                                                            <option value="<?php echo $row['AuthorId']; ?>" <?php echo (isset($authorsArray) && $authorsArray[0] === $row['AuthorId']) ? 'selected': ''; ?>><?php echo $row['AuthorName']; ?></option>
                                                            <?php
                                                                    }
                                                                } else {
                                                            ?>
                                                            <option value="" selected>No data available</option>
                                                            <?php }  ?>
                                                        </select>
                                                    </div>
                                                <?php } ?>
                                                </div>
                                                <?php if (isset($errors['authors'])) { ?>
                                                <span class="help-inline"><?php echo $errors['authors']; ?></span>
                                                <?php } ?>
                                                <hr/>
                                                <a class="field-authors-btn <?php echo count($authorsResults) ? '' : 'hidden' ?>" >+ Add more authors</a> <br/>
                                                <a href="#modal-add-author" class="add-on btn-add-author" data-toggle="modal">+ Create an Author</a>
                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['publisher']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="publisher"><span class="is-required">*</span> <b>Publisher</b></label>
                                            <div class="controls">

                                                    <select id="publisher" name="publisher" class="span8 select-publisher">
                                                        <?php
                                                            if ($total_publishers > 0) {
                                                                while($row = $publishers->fetch_assoc()) {
                                                        ?>
                                                        <option value="<?php echo $row['PublisherId']; ?>" <?php echo (isset($publisher) && $publisher === $row['PublisherId']) ? 'selected': ''; ?>><?php echo $row['Publisher']; ?></option>
                                                        <?php
                                                                }
                                                            } else {
                                                        ?>
                                                        <option value="" selected>No data available</option>
                                                        <?php }  ?>
                                                    </select>
                                                    <?php if (isset($errors['publisher'])) { ?>
                                                    <span class="help-inline"><?php echo $errors['publisher']; ?></span> <br/>
                                                    <?php } ?>
                                                     <br/>
                                                    <a href="#modal-add-publisher" class="btn-add-publisher" data-toggle="modal">+ Create a Publisher</a>

                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['year']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="year"><span class="is-required">*</span> <b>Year</b></label>
                                            <div class="controls">
                                                <input type="number" id="year" name="year" placeholder="Year" class="span8" value="<?php echo isset($year) ? $year : ''; ?>" required>
                                                <?php if (isset($errors['year'])) { ?>
                                                <span class="help-inline"><?php echo $errors['year']; ?></span>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['type']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="type"><span class="is-required">*</span> <b>Type</b></label>
                                            <div class="controls">
                                                <select id="type" name="type" class="span8 select-type">
                                                    <?php
                                                        if ($total_types > 0) {
                                                            while($row = $types->fetch_assoc()) {
                                                    ?>
                                                    <option value="<?php echo $row['TypeId']; ?>" <?php echo (isset($type) && $type === $row['TypeId']) ? 'selected': ''; ?>><?php echo $row['Type']; ?></option>
                                                    <?php
                                                            }
                                                        }  ?>
                                                </select> <?php if (isset($errors['type'])) { ?>
                                                    <span class="help-inline"><?php echo $errors['type']; ?></span> <br/>
                                                    <?php } ?> <br/>
                                                <a href="#modal-add-type" class="btn-add-type" data-toggle="modal">+ Create a Type</a>
                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['category']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="category"><span class="is-required">*</span> <b>Categories</b></label>
                                            <div class="controls">
                                                <select id="category" name="category[]" multiple class="span8 select-category">
                                                    <?php
                                                        if ($total_categories > 0) {
                                                            while($row = $categories->fetch_assoc()) {
                                                    ?>
                                                    <option value="<?php echo $row['CatalogueCatId']; ?>" <?php echo (isset($categoryArray) && in_array($row['CatalogueCatId'], $categoryArray)) ? 'selected': ''; ?>><?php echo $row['Category']; ?></option>
                                                    <?php
                                                            }
                                                        }
                                                         ?>
                                                </select> <?php if (isset($errors['category'])) { ?>
                                                    <span class="help-inline"><?php echo $errors['category']; ?></span> <br/>
                                                    <?php } ?> <br/>
                                                <a href="#modal-add-category" class="btn-add-category" data-toggle="modal">+ Create a Category</a>
                                            </div>
                                        </div>
                                        <div class="control-group <?php echo isset($errors['quantity']) ? 'error' : ''; ?>">
                                            <label class="control-label" for="quantity"><b>Quantity</b></label>
                                            <div class="controls" style="margin-bottom: 5px;">
                                                <div class="input-prepend">
                                                    <span class="add-on" style="width: 100px">Available: </span>
                                                    <input type="number" name="quantity" placeholder="Number of Copies" class="span8" value="<?php echo isset($quantity) ? $quantity : 1; ?>" required>
                                                </div>
                                                <?php if (isset($errors['quantity'])) { ?>
                                                    <span class="help-inline"><?php echo $errors['quantity']; ?></span>
                                                    <?php } ?>
                                            </div>
                                            <div class="controls" style="margin-bottom: 5px;">
                                                <div class="input-prepend">
                                                    <span class="add-on" style="width: 100px">Borrowed: </span>
                                                    <input type="number" readonly  class="span8" value="<?php echo isset($availability['Borrowed']['Quantity']) ? $availability['Borrowed']['Quantity'] : 0 ?>">
                                                </div>
                                            </div>

                                            <div class="controls" style="margin-bottom: 5px;">
                                                <div class="input-prepend">
                                                    <span class="add-on" style="width: 100px">Missing: </span>
                                                    <input type="number" readonly class="span8" value="<?php echo isset($availability['Missing']['Quantity']) ? $availability['Missing']['Quantity'] : 0 ?>">
                                                </div>
                                            </div>

                                            <div class="controls" style="margin-bottom: 5px;">
                                                <div class="input-prepend">
                                                    <span class="add-on" style="width: 100px">Damaged: </span>
                                                    <input type="number" readonly  class="span8" value="<?php echo isset($availability['Damaged']['Quantity']) ? $availability['Damaged']['Quantity'] : 0 ?>">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="control-group">
                                            <div class="controls">
                                                <button type="submit" name="submit" class="btn">Update Details</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                        </div>
                    </div>

                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php'); ?>

        <?php include('common/modal-add-author.php'); ?>
        <?php include('common/modal-add-publisher.php'); ?>
        <?php include('common/modal-add-category.php'); ?>
        <?php include('common/modal-add-type.php'); ?>
    </body>

</html>