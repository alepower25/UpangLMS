<?php
require('dbconn.php');

include('common/access-check.php');

$pageTitle = "Advanced Search";
?>
<!DOCTYPE html>
    <html lang="en">

    <head>
        <?php include('common/head.php'); ?>
        <style type="text/css">
            #tables_filter input {
                width: 300px;
            }
        </style>
    </head>

    <body>
        <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php'); ?>

                    <div class="span9">
                        <?php

                            $sql = 'select * from records join catalogue on catalogue.CatalogueId = records.CatalogueId JOIN users on users.UserId = records.UserId where DateOfIssue IS NOT NULL and DateOfReturn IS NULL';
                        $result = $conn->query($sql);


                        ?>
                            <table class="table datatable-2" id="tables">
                                <thead>
                                    <tr>
                                        <th>Book id</th>
                                        <th>Student No</th>
                                        <th>Title</th>
                                        <th>ISBN</th>
                                       <!--  <th>Issue Date</th>
                                        <th>Due date</th> -->
                                        <th>Penalty per Day</th>
                                        <th>Due (₱)</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php
                                    if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $rollno = $row['RollNo'];
                                        $bookid = $row['CatalogueId'];
                                        $name = $row['Title'];
                                        $issuedate = $row['DateOfIssue'];
                                        $duedate = $row['DueDate'];
                                        $dues = compute_penalty($duedate);

                                    ?>

                                        <tr>
                                            <td><?php echo $bookid ?></td>
                                            <td><?php echo strtoupper($rollno) ?></td>
                                            <td><?php echo $name ?></td>
                                            <td><?php echo $row['Isbn'] ?></td>
                                            <!-- <td><?php echo $issuedate ?></td>
                                            <td><?php echo $duedate ?></td> -->
                                            <td>₱120 per day (fixed value)</td>
                                            <td><?php if ($dues > 0)
                                                    echo "<font color='red'>" . number_format($dues, 2) . "</font>";
                                                else
                                                    echo "<font color='green'>0</font>";
                                                ?></td>
                                        </tr>
                                <?php }
                            }
                                 ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="5" style="text-align:right">Total Penalties of Students:</th>
                                        <th></th>
                                    </tr>
                                </tfoot>
                            </table>
                    </div>

                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php'); ?>
        <script type="text/javascript">
            $(document).ready(function() {

                $('.datatable-2').dataTable({
                    lengthMenu: [500, 1000, 5000, 10000],
                    language: {
                        searchPlaceholder: 'Enter Student Number/Book Name/Book Id/ISBN'
                    },
                    footerCallback: function (row, data, start, end, display) {
                        var api = this.api();

                        // Remove the formatting to get integer data for summation
                        var intVal = function (i) {
                            return typeof i === 'string' ? i.replace(/(<([^>]+)>)/gi, "") * 1 : typeof i === 'number' ? i : 0;
                        };

                        // Total over all pages
                        total = api
                            .column(5)
                            .data()
                            .reduce(function (a, b) {
                                return intVal(a) + intVal(b);
                            }, 0);

                        // Update footer
                        $(api.column(5).footer()).html('₱' + total.toFixed(2) + ' total');
                    },
                });
                $('.dataTables_paginate').addClass('btn-group datatable-pagination');
                $('.dataTables_paginate > a').wrapInner('<span />');
                $('.dataTables_paginate > a:first-child').append('<i class="icon-chevron-left shaded"></i>');
                $('.dataTables_paginate > a:last-child').append('<i class="icon-chevron-right shaded"></i>');
            });
        </script>
    </body>

    </html>