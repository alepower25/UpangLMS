<?php
require('dbconn.php');

include('common/header-json.php');
include('common/access-check.php');
include('common/check-error-422.php');

$publisher = isset($_POST['publisher']) ? $_POST['publisher'] : null;

if (empty($publisher)) {
    http_response_code(422);
    echo json_encode(['errors' => [['key' => 'publisher', 'val' => 'Publisher field is required.']], 'message' => 'Please correct the errors found.']);
    exit;
}

$conn->query('INSERT INTO publishers (Publisher) VALUES ("' . $conn->real_escape_string($publisher) . '")');

if ($conn->affected_rows < 1) {
    http_response_code(422);
    echo json_encode(['message' => 'Unable to insert data into the database.']);
    exit;
}

echo json_encode(['message' => 'Publisher has been successfully added!', 'data' => ['id' => $conn->insert_id, 'value' => $publisher]]);