<?php

require('dbconn.php');

if (!isset($_POST['id'])) {
    exit;
}

//sends the query to delete the entry
$conn->query('SET FOREIGN_KEY_CHECKS=0');
$result = $conn->query('DELETE FROM users WHERE UserId = "'.$conn->real_escape_string($_POST['id']).'"');

if ($result) {
//if it updated
?>

            <strong>Student Has Been Removed</strong><br /><br />
    
<?php
 } else { 
    echo  $conn->error;
//if it failed
?>
    
            <strong>Deletion Failed</strong><br /><br />
    

<?php
} 
?>