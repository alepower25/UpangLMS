<?php
require('dbconn.php');

include('common/access-check.php');

$id = isset($_GET['id']) ? $conn->real_escape_string($_GET['id']) : null;

if (empty($id)) {
    http_response_code(422);
    exit;
}

$recordResult = $conn->query('SELECT Id, users.UserId, users.RollNo, CatalogueId, DueDate FROM records JOIN users ON users.UserId = records.UserId WHERE Id = '. $id);

if ($recordResult->num_rows == 0) {
    http_response_code(422);
    exit;
}

$recordRow = $recordResult->fetch_assoc();

$dues = compute_penalty($recordRow['DueDate']);

$conn->query('UPDATE records SET DateOfReturn = CURDATE(), Dues = "'.$dues.'" WHERE Id = '.$recordRow['Id']);
 
if($conn->affected_rows > 0) {
    $conn->query('UPDATE catalogue_meta SET Quantity = Quantity + 1 WHERE `Status` = "Damaged" AND CatalogueId = '. $recordRow['CatalogueId']);

    $conn->query('UPDATE catalogue_meta SET Quantity = Quantity - 1 WHERE `Status` = "Borrowed" AND CatalogueId = '. $recordRow['CatalogueId']);

    $conn->query('DELETE FROM returns WHERE RecordId = '. $recordRow['Id']);

    $conn->query('DELETE FROM renewals WHERE RecordId = '. $recordRow['Id']);

    $conn->query('insert into message (RollNo,Msg,Date,Time,UserId) values ("'.$recordRow['RollNo'].'", "Your request for return of BookId: '.$recordRow['CatalogueId'].'  has been accepted and marked as damaged.",curdate(),curtime(), '.$recordRow['UserId'].' )');

    echo "<script type='text/javascript'>alert('Success')</script>";
    header( "Refresh:0.01; url=return_requests.php", true, 303);
}
else
{
	echo "<script type='text/javascript'>alert('Error')</script>";
    header( "Refresh:1; url=return_requests.php", true, 303);

}





?>