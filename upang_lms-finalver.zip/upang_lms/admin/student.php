<?php
require('dbconn.php');

include('common/access-check.php');

if (isset($_POST['addstudent'])) {
    $errors = [];

    $rollno = isset($_POST['rollno']) ? trim($_POST['rollno']) : null;
    $firstname = isset($_POST['firstname']) ? trim($_POST['firstname']) : null;
    $lastname = isset($_POST['lastname']) ? trim($_POST['lastname']) : null;
    $emailid = isset($_POST['emailid']) ? trim($_POST['emailid']) : null;
    $mobileno = isset($_POST['mobileno']) ? $_POST['mobileno'] : null;
    $password = isset($_POST['lastname']) ? sha1(strtoupper($_POST['lastname'])) : null;
    $department = isset($_POST['department']) ? $_POST['department'] : null;

    if (empty($rollno)) {
        $errors['rollno'] = 'The Student No. field is required.';
    }

    if (empty($firstname)) {
        $errors['firstname'] = 'The First Name field is required.';
    }

    if (empty($lastname)) {
        $errors['lastname'] = 'The Last Name field is required.';
    }

    if (empty($emailid)) {
        $errors['emailid'] = 'The Email Id field is required.';
    } else {
        if (!filter_var($emailid, FILTER_VALIDATE_EMAIL)) {
          $errors['emailid'] = 'Invalid email format.';
        }
    }

    if (!empty($mobileno) && !is_numeric($mobileno)) {
        $errors['mobileno'] = 'The Mobile No. field should be numbers only. (e.g. 09123456789).';
    }

    if (empty($department)) {
        $errors['department'] = 'The Department field is required.';
    }

    $duplicate = $conn->query('SELECT UserId FROM users WHERE `RollNo` = "'.$conn->real_escape_string($rollno).'" LIMIT 1');

    if ($duplicate->num_rows > 0) {
        $errors['rollno'] = 'Student No. already exists! Please use a different Student No!';
    }

    $duplicate = $conn->query('SELECT UserId FROM users WHERE `Email` = "'.$conn->real_escape_string($emailid).'" LIMIT 1');

     if ($duplicate->num_rows > 0) {
        $errors['emailid'] = 'Email already exists! Please use a different Email!';
    }

    if (!count($errors)) {
        $name = $firstname . " ". $lastname;

        $conn->query('INSERT INTO users (RollNo, Name, Type, DepartmentId, Email, MobileNo, Password) VALUES ("'.$conn->real_escape_string($rollno).'", "'.$conn->real_escape_string($name).'", "student", '.$conn->real_escape_string($department).',"'.$conn->real_escape_string($emailid).'","'.$conn->real_escape_string($mobileno).'","'.$password .'")');

        if ($conn->affected_rows > 0 ) {
            $student_id = $conn->insert_id;
            $success = true;

            unset($rollno);
            unset($firstname);
            unset($lastname);
            unset($emailid);
            unset($mobileno);
            unset($department);
        } else {
            $errors[] = [];
            $message = 'Ooops! Something went wrong!';
        }
    } else {
        $message = isset($message) ? $message : 'Please correct the errors found.';
    }


}


$studentsResults = $conn->query('select users.*, departments.Code from users JOIN departments ON departments.DepartmentId = users.DepartmentId where `Type` = "student"');

$deparmentsResults = $conn->query('SELECT * FROM departments ORDER BY Department ASC');

?>
<!DOCTYPE html>
    <html lang="en">

    <head>
        <?php include('common/head.php'); ?>
    </head>

    <body>
        <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php'); ?>

                    <div class="span9">
                        <!-- <div class="form-horizontal row-fluid" style="margin-bottom: 25px;">
                            <div class="control-group">
                                <label class="control-label" for="Search"><b>Search:</b></label>
                                <div class="controls">
                                    <input type="text" id="title" name="title" placeholder="Enter Name/Student Number" class="span8" required>
                                    <button type="submit" name="submit" class="btn">Search</button>
                                </div>
                            </div>
                        </div> -->
                        <form class="form-horizontal row-fluid" action="student.php" method="post">
                            <?php if (isset($errors) && count($errors) > 0) { ?>
                                <div class="alert alert-danger"><?php echo $message; ?></div>
                            <?php } ?>
                            <?php if (isset($success) && $success) {?>
                            <div class="alert alert-success">Student has been added. Click <a href="/admin/studentdetails.php?id=<?php echo $$student_id; ?>">here</a> to view.</div>
                            <?php } ?>
                            <div class="control-group <?php echo isset($errors['rollno']) ? 'error' : ''; ?>">
                                <label class="control-label" for="rollno"><b>Student No.</b></label>
                                <div class="controls">
                                    <input type="text" id="rollno" name="rollno" placeholder="Student Number" class="span8" required value="<?php echo isset($rollno) ? $rollno : ''; ?>">
                                    <?php if (isset($errors['rollno'])) { ?>
                                    <span class="help-inline"><?php echo $errors['rollno']; ?></span>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="control-group <?php echo isset($errors['firstname']) ? 'error' : ''; ?>">
                                <label class="control-label" for="firstname"><b>First Name</b></label>
                                <div class="controls">
                                    <input type="text" id="firstname" name="firstname" placeholder="First Name" class="span8" required value="<?php echo isset($firstname) ? $firstname : ''; ?>">
                                    <?php if (isset($errors['firstname'])) { ?>
                                    <span class="help-inline"><?php echo $errors['firstname']; ?></span>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="control-group <?php echo isset($errors['lastname']) ? 'error' : ''; ?>">
                                <label class="control-label" for="lastname"><b>Last Name</b></label>
                                <div class="controls">
                                    <input type="text" id="lastname" name="lastname" placeholder="Last Name" class="span8" required value="<?php echo isset($lastname) ? $lastname : ''; ?>">
                                    <?php if (isset($errors['lastname'])) { ?>
                                    <span class="help-inline"><?php echo $errors['lastname']; ?></span>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="control-group <?php echo isset($errors['department']) ? 'error' : ''; ?>">
                                <label class="control-label" for="department"><b>Department</b></label>
                                <div class="controls">
                                    <select id="department" name="department" class="span8">
                                        <?php
                                            if ($deparmentsResults->num_rows > 0) {
                                                while ($departmentRow = $deparmentsResults->fetch_assoc()) {
                                        ?>
                                        <option value="<?php echo $departmentRow['DepartmentId'] ?>" <?php echo (isset($department) && $department === $departmentRow['DepartmentId']) ? 'selected' : ''; ?>><?php echo $departmentRow['Code'] ?></option>
                                        <?php
                                                }
                                            }
                                        ?>
                                    </select>
                                    <?php if (isset($errors['department'])) { ?>
                                    <span class="help-inline"><?php echo $errors['department']; ?></span>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="control-group <?php echo isset($errors['emailid']) ? 'error' : ''; ?>">
                                <label class="control-label" for="emailid"><b>Email ID</b></label>
                                <div class="controls">
                                    <input type="email" id="emailid" name="emailid" placeholder="Email ID" class="span8" required value="<?php echo isset($emailid) ? $emailid : ''; ?>">
                                    <?php if (isset($errors['emailid'])) { ?>
                                    <span class="help-inline"><?php echo $errors['emailid']; ?></span>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="control-group <?php echo isset($errors['mobileno']) ? 'error' : ''; ?>">
                                <label class="control-label" for="mobileno"><b>Mobile No.</b></label>
                                <div class="controls">
                                    <input type="text" id="mobileno" name="mobileno" placeholder="Mobile No." class="span8" required value="<?php echo isset($mobileno) ? $mobileno : ''; ?>">
                                    <?php if (isset($errors['mobileno'])) { ?>
                                    <span class="help-inline"><?php echo $errors['mobileno']; ?></span>
                                    <?php } ?>
                                </div>
                            </div>
                            <!-- <div class="control-group">
                                <label class="control-label" for="password"><b>Password</b></label>
                                <div class="controls">
                                    <input type="text" id="password" name="password" placeholder="Password" class="span8" required>
                                </div>
                            </div> -->
                            <div class="control-group">
                                <div class="controls">
                                    <button type="submit" name="addstudent" class="btn">Add Student</button>
                                    <span>or</span>
                                    <a href="#modal-import-students" data-toggle="modal" class="btn btn-link">Import Students</a>
                                </div>
                            </div>
                        </form>
                        <br>
                        <table class="table datatable-2" id="tables">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Student Number</th>
                                        <th>PHINMA Email</th>
                                        <th>Department</th>
                                        <th><div class="text-center">Actions</div></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                    if ($studentsResults->num_rows > 0) {
                                    while ($row = $studentsResults->fetch_assoc()) {

                                        $email = $row['Email'];
                                        $name = $row['Name'];
                                        $rollno = $row['RollNo'];
                                    ?>
                                        <tr>
                                            <td><?php echo $name ?></td>
                                            <td><?php echo $rollno ?></td>
                                            <td><?php echo $email ?></td>
                                            <td><?php echo $row['Code']; ?></td>
                                            <td>
                                                <center>
                                                    <a href="studentdetails.php?id=<?php echo $row['UserId']; ?>" class="btn btn-success">Details</a>
                                                    <form style="display: inline-block;" method="post" action="remove_student.php">
                                                        <input type="hidden" name="id" value="<?php echo $row['UserId']; ?>">
                                                        <button type="button" class="btn btn-danger btn-delete-student">Remove</button>
                                                    </form>
                                                </center>
                                            </td>
                                        </tr>
                                <?php }
                            }
                                ?>
                                </tbody>
                            </table>
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php'); ?>

        <?php include('modal-students-import.php'); ?>

        <script type="text/javascript">
            $(document).ready(function() {

                $('.datatable-2').dataTable({
                    lengthMenu: [500, 1000, 5000, 10000],
                    language: {
                        searchPlaceholder: 'Enter Name/Student Number'
                    }
                });
                $('.dataTables_paginate').addClass('btn-group datatable-pagination');
                $('.dataTables_paginate > a').wrapInner('<span />');
                $('.dataTables_paginate > a:first-child').append('<i class="icon-chevron-left shaded"></i>');
                $('.dataTables_paginate > a:last-child').append('<i class="icon-chevron-right shaded"></i>');

                $('.btn-delete-student').on('click', function(e) {
                    e.preventDefault();

                    var result = confirm('Are you sure you want to delete this student?');

                    if (result) {
                        $(this).closest('form').submit();
                    }
                })

            });
        </script>
    </body>

</html>
