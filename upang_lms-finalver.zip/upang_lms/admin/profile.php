<?php
require('dbconn.php');

include('common/access-check.php');

$pageTitle = "Your Profile";

if (isset($_POST['submit'])) {
    $errors = [];
    $rollno = $_SESSION['RollNo'];
    $name = isset($_POST['Name']) ? trim($_POST['Name']) : null;
    $email = isset($_POST['EmailId']) ? trim($_POST['EmailId']): null;
    $mobno = isset($_POST['MobNo']) ? trim($_POST['MobNo']) : null;
    $pswd = isset($_POST['Password']) ? $_POST['Password'] : null;

    if (empty($name)) {
        $errors['name'] = 'The Name field is required.';
    }

    if (empty($email)) {
        $errors['email'] = 'The Email Id field is required.';
    } else {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          $errors['email'] = 'Invalid email format.';
        }
    }

    if (!empty($mobno) && !is_numeric($mobno)) {
        $errors['mobno'] = 'The Mobile No. field should be numbers only. (e.g. 09123456789).';
    }

    $duplicate = $conn->query('SELECT UserId FROM users WHERE LOWER(Email) = "'.$conn->real_escape_string(strtolower($email)).'" AND RollNo != "'.$rollno.'" LIMIT 1');

    if ($duplicate->num_rows > 0) {
        $errors['email'] = 'Email already exists! Please use a different Email!';
    }

    if (!count($errors)) {

        $updateSql = 'update users set Name="'.$conn->real_escape_string($name).'", Email="'.$conn->real_escape_string($email).'", MobileNo="'.$conn->real_escape_string($mobno).'"';

        if ($pswd !== null && !empty($pswd)) {
            $updateSql .= ', Password = "'.$conn->real_escape_string(sha1($pswd)).'"';
        }

        $updateSql .= ' WHERE RollNo = "'.$rollno.'"';

        $conn->query($updateSql);

        $success = true;

    }  else {
        $message = isset($message) ? $message : 'Please correct the errors found.';
    }
}
?>

<!DOCTYPE html>
    <html lang="en">

    <head>
        <?php include('common/head.php'); ?>
    </head>

    <body>
        <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php'); ?>

                    <div class="span9">
                        <div class="module">
                            <div class="module-head">
                                <h3>Update Details</h3>
                            </div>
                            <div class="module-body">


                                <?php
                                $rollno = $_SESSION['RollNo'];
                                $sql = "select * from users where RollNo='$rollno'";
                                $result = $conn->query($sql);
                                $row = $result->fetch_assoc();

                                $name = $row['Name'];
                                $email = $row['Email'];
                                $mobno = $row['MobileNo'];
                                ?>

                                <form class="form-horizontal row-fluid" action="profile.php" method="post">
                                    <?php if (isset($errors) && count($errors) > 0) { ?>
                                    <div class="alert alert-danger"><?php echo $message; ?></div>
                                    <?php } ?>
                                    <?php if (isset($success) && $success) {?>
                                    <div class="alert alert-success">Profile has been updated!</div>
                                    <?php } ?>
                                    <div class="control-group <?php echo isset($errors['name']) ? 'error' : ''; ?>">
                                        <label class="control-label" for="Name"><b>Name:</b></label>
                                        <div class="controls">
                                            <input type="text" id="Name" name="Name" value="<?php echo $name ?>" class="span8" required>
                                            <?php if (isset($errors['name'])) { ?>
                                    <span class="help-inline"><?php echo $errors['name']; ?></span>
                                    <?php } ?>
                                        </div>
                                    </div>

                                    <div class="control-group  <?php echo isset($errors['email']) ? 'error' : ''; ?>">
                                        <label class="control-label" for="EmailId"><b>Email Id:</b></label>
                                        <div class="controls">
                                            <input type="text" id="EmailId" name="EmailId" value="<?php echo $email ?>" class="span8" required>
                                            <?php if (isset($errors['email'])) { ?>
                                    <span class="help-inline"><?php echo $errors['email']; ?></span>
                                    <?php } ?>
                                        </div>
                                    </div>

                                    <div class="control-group <?php echo isset($errors['mobno']) ? 'error' : ''; ?>">
                                        <label class="control-label" for="MobNo"><b>Mobile Number:</b></label>
                                        <div class="controls">
                                            <input type="text" id="MobNo" name="MobNo" value="<?php echo $mobno ?>" class="span8">
                                            <?php if (isset($errors['mobno'])) { ?>
                                    <span class="help-inline"><?php echo $errors['mobno']; ?></span>
                                    <?php } ?>
                                        </div>
                                    </div>

                                    <div class="control-group">
                                        <label class="control-label" for="Password"><b>New Password:</b></label>
                                        <div class="controls">
                                            <input type="password" id="Password" name="Password" class="span8" />
                                            <span class="help-inline">Leave blank to retain current password</span>
                                        </div>
                                    </div>

                                    <div class="control-group">
                                        <div class="controls">
                                            <button type="submit" name="submit" class="btn-primary">
                                                <center>Update Details</center>
                                            </button>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>

                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php'); ?>
    </body>

</html>