<div id="modal-import-books" class="modal hide fade">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h3>Import Materials</h3>
  </div>
  <div class="modal-body">
    <form id="form-import-books"  method="post" action="importbooks.php">
      <p>Click <a href="javascript:download_format()">here</a> to download the file format.</p>
      <div class="control-group">
          <label>Select a CSV file to import:</label>
          <input id="input-file" type="file" name="file" />
      </div>
  </form>
  </div>
  <div class="modal-footer">
    <a href="#" class="btn" data-dismiss="modal">Cancel</a>
    <button type="button" class="btn btn-info btn-import-books">Import</button>
  </div>
</div>

<script type="text/javascript">
  function download_format() {
    var csv = 'Title,ISBN,Author(s) (Separate by pipe (|) for multiple authors), Publisher, Year, Type, Categories (Separate by pipe (|) for multiple categories), Quantity \n';

    var hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    hiddenElement.target = '_blank';

    hiddenElement.download = 'ImportBooks.csv';
    hiddenElement.click();
  }

  $(document).ready(function () {
    var $modalImportBooks = $('#modal-import-books');
    var $formImportBooks = $('#form-import-books');

    $(document).delegate('.btn-import-books', 'click', function (e) {
      var $btn = $(e.currentTarget);
      var formData = new FormData();
      var $file = $('#input-file');

      if ($file[0].files.length < 1 ){
        return;
      }

      formData.append('file', $file[0].files[0]);

      $.ajax({
        url: $formImportBooks.prop('action'),
        method: $formImportBooks.prop('method'),
        dataType: 'json',
        processData: false,
        contentType: false,
        cache: false,
        enctype: 'multipart/form-data',
        beforeSend: function () {
          $btn.prop('disabled', true);
          $modalImportBooks.find('.alert').remove();
          $modalImportBooks.find('.error .help-inline').remove();
          $modalImportBooks.find('.error').removeClass('error');
          $modalImportBooks.append('<div class="loader"><span>Loading...</span></div>');
        },
        data: formData,
        error: function (err) {
          var response = $.parseJSON(err.responseText);

          $formImportBooks.prepend('<div class="alert alert-danger">'+response.message+'</div>');

          if (!response.hasOwnProperty('errors')) {
            return;
          }

          $.each(response.errors, function (index, value) {
            var $inputEl = $('#input-' + value.key);
            $inputEl.parent('.control-group').addClass('error');
            $('<span class="help-inline">'+value.val+'</span>').insertAfter($inputEl);
          });
        },
        success: function (response) {
          $formImportBooks[0].reset();
          $formImportBooks.prepend('<div class="alert alert-'+response.type+'">'+response.message+'</div>');

        },
        complete: function () {
          $btn.prop('disabled', false);
          $('.loader').remove();
        }
      });
    });


    $modalImportBooks.on('hide', function () {
      $formImportBooks[0].reset();
      $modalImportBooks.find('.alert').remove();
      $modalImportBooks.find('.error .help-inline').remove();
      $modalImportBooks.find('.error').removeClass('error');
    })
  });
</script>