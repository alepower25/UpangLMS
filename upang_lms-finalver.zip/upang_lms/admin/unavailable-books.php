<?php
require('dbconn.php');

$unavaibaleBooksResult = $conn->query('SELECT * FROM catalogue JOIN catalogue_meta ON catalogue_meta.CatalogueId = catalogue.CatalogueId WHERE `Status` = "Available" AND Quantity = 0 ORDER BY catalogue.CatalogueId ASC');


$pageTitle = "Unvailable Books";

include('common/access-check.php');
?>
<!DOCTYPE html>
    <html lang="en">

    <head>
         <?php include('common/head.php'); ?>
         <style type="text/css">
             .dt-buttons {
                float: left!important;
                margin-left: 12%!important;
             }
         </style>
    </head>

    <body>
        <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php'); ?>

                    <div class="span9">
                            <table class="table datatable-2" id="tables">
                                <thead>
                                    <tr>
                                        <th>Book id</th>
                                        <th>Title</th>
                                        <th>ISBN</th>
                                        <th>Availability</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    if ($unavaibaleBooksResult->num_rows) {
                                        while ($row = $unavaibaleBooksResult->fetch_assoc()) {
                                ?>
                                        <tr>
                                            <td><?php echo $row['CatalogueId']; ?></td>
                                            <td><?php echo $row['Title']; ?></td>
                                            <td><?php echo $row['Isbn']; ?></td>
                                            <td><b><?php echo $row['Quantity']; ?></b></td>
                                            </td>
                                        </tr>
                                <?php
                                        }
                                    }
                                ?>
                                </tbody>
                            </table>
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php'); ?>

        <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
        <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
        <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                $('.datatable-2').dataTable( {
                    lengthMenu: [500, 1000, 5000, 10000],
                    language: {
                        searchPlaceholder: 'Enter Book Name/Book Id/ISBN'
                    },
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'pdf',
                            text: 'Export to PDF',
                            className: 'btn btn-default'
                        },
                        {
                            extend: 'print',
                            className: 'btn btn-default'
                        }
                    ]
                } );

                $('.dataTables_paginate').addClass('btn-group datatable-pagination');
                $('.dataTables_paginate > a').wrapInner('<span />');
                $('.dataTables_paginate > a:first-child').append('<i class="icon-chevron-left shaded"></i>');
                $('.dataTables_paginate > a:last-child').append('<i class="icon-chevron-right shaded"></i>');
            } );
        </script>

    </body>

    </html>