<div id="modal-import-students" class="modal hide fade">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h3>Import Students</h3>
  </div>
  <div class="modal-body">
    <form id="form-import-students"  method="post" action="importstudents.php">
      <p>Click <a href="javascript:download_format()">here</a> to download the file format.</p>
      <div class="control-group">
          <label>Select a CSV file to import:</label>
          <input id="input-file" type="file" name="file" />
      </div>
  </form>
  </div>
  <div class="modal-footer">
    <a href="#" class="btn" data-dismiss="modal">Cancel</a>
    <button type="button" class="btn btn-info btn-import-books">Import</button>
  </div>
</div>

<script type="text/javascript">
  function download_format() {
    var csv = 'Student Number,First Name, Last Name, Department (3 or 4 letter code), Email, Mobile No. \n';

    var hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    hiddenElement.target = '_blank';

    hiddenElement.download = 'ImportStudents.csv';
    hiddenElement.click();
  }

  $(document).ready(function () {
    var $modalImportStudents = $('#modal-import-students');
    var $formImportStudents = $('#form-import-students');

    $(document).delegate('.btn-import-books', 'click', function (e) {
      var $btn = $(e.currentTarget);
      var formData = new FormData();
      var $file = $('#input-file');

      if ($file[0].files.length < 1 ){
        return;
      }

      formData.append('file', $file[0].files[0]);

      $.ajax({
        url: $formImportStudents.prop('action'),
        method: $formImportStudents.prop('method'),
        dataType: 'json',
        processData: false,
        contentType: false,
        cache: false,
        enctype: 'multipart/form-data',
        beforeSend: function () {
          $btn.prop('disabled', true);
          $modalImportStudents.find('.alert').remove();
          $modalImportStudents.find('.error .help-inline').remove();
          $modalImportStudents.find('.error').removeClass('error');
          $modalImportStudents.append('<div class="loader"><span>Loading...</span></div>');
        },
        data: formData,
        error: function (err) {
          var response = $.parseJSON(err.responseText);

          $formImportStudents.prepend('<div class="alert alert-danger">'+response.message+'</div>');

          if (!response.hasOwnProperty('errors')) {
            return;
          }

          $.each(response.errors, function (index, value) {
            var $inputEl = $('#input-' + value.key);
            $inputEl.parent('.control-group').addClass('error');
            $('<span class="help-inline">'+value.val+'</span>').insertAfter($inputEl);
          });
        },
        success: function (response) {
          var $selectAuthor = $('.select-publisher');

          $formImportStudents[0].reset();
          $formImportStudents.prepend('<div class="alert alert-success">'+response.message+'</div>');

        },
        complete: function () {
          $btn.prop('disabled', false);
          $('.loader').remove();
        }
      });
    });


    $modalImportStudents.on('hide', function () {
      $formImportStudents[0].reset();
      $modalImportStudents.find('.alert').remove();
      $modalImportStudents.find('.error .help-inline').remove();
      $modalImportStudents.find('.error').removeClass('error');
    })
  });
</script>