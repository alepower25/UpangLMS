<?php
require('dbconn.php');

include('common/access-check.php');

?>
<!DOCTYPE html>
    <html lang="en">

    <head>
        <?php include('common/head.php'); ?>
    </head>

    <body>
        <?php include('common/top-navbar.php'); ?>
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <?php include('common/sidebar.php'); ?>

                    <div class="span9">
                        <div class="content">

                            <div class="module">
                                <div class="module-head">
                                    <h3>Student Details</h3>
                                </div>
                                <div class="module-body">
                                    <?php
                                    $rno = $_GET['id'];
                                    $result = $conn->query( "select users.*, departments.Code from users JOIN departments on departments.DepartmentId = users.DepartmentId where UserId = ".$conn->real_escape_string($rno)." LIMIT 1");
                                    $row = $result->fetch_assoc();

                                    $name = $row['Name'];
                                    $email = $row['Email'];
                                    $mobno = !empty($row['MobileNo']) ? $row['MobileNo'] : 'None';


                                    echo "<b><u>Name:</u></b> " . $name . "<br><br>";
                                    echo "<b><u>Student No:</u></b> " . $row['RollNo'] . "<br><br>";
                                    echo "<b><u>Department:</u></b> " . $row['Code'] . "<br><br>";
                                    echo "<b><u>Email Id:</u></b> " . $email . "<br><br>";
                                    echo "<b><u>Mobile No:</u></b> " . $mobno . "<br><br>";
                                    ?>

                                    <a href="student.php" class="btn btn-primary">Go Back</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/.span9-->

                </div>
            </div>
            <!--/.container-->
        </div>
        <?php include('common/footer.php'); ?>

    </body>

</html>